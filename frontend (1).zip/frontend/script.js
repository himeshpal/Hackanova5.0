// ═══════════════════════════════════════════════════════════════════════════════
// RESEARCHORACLE — INTELLIGENCE DASHBOARD
// script.js — Single source of truth, reactive state, D3 graph, SSE bridge
// ═══════════════════════════════════════════════════════════════════════════════

'use strict';

// ══ 1. GLOBAL STATE — single source of truth ══════════════════════════════════
// All components read from and write to AppState. Dashboard, Graph, and
// Open Questions panels are all subscribed via AppState.subscribe().

const AppState = (function () {
  const _state = {
    papers:          10,
    citations:       36,
    contradictions:  4,
    gaps:            15,
    foundational:    3,
    methods:         5,
    syncing:         false,   // true while SSE batch is being processed
    lastBatch:       null,    // ISO timestamp of last SSE batch
    nodeCount:       0,       // live count driven by graph data
    edgeCount:       0,
  };

  const _listeners = [];

  function get(key)         { return _state[key]; }
  function getAll()         { return Object.assign({}, _state); }
  function subscribe(fn)    { _listeners.push(fn); }

  function set(patch) {
    Object.assign(_state, patch);
    _listeners.forEach(function (fn) { fn(Object.assign({}, _state)); });
  }

  return { get, getAll, set, subscribe };
}());

// ══ 2. PAPER METADATA ════════════════════════════════════════════════════════

const PM = {
  '2110.06500': { t:'Parameter-efficient methods for private fine-tuning of large LMs',       u:'https://arxiv.org/abs/2110.06500' },
  '2312.10793': { t:'Mixing instruction datasets for LLM fine-tuning: a systematic study',   u:'https://arxiv.org/abs/2312.10793' },
  '2402.11651': { t:'Negative-aware training (NAT) for LLM agent fine-tuning',               u:'https://arxiv.org/abs/2402.11651' },
  '2309.13734': { t:'Investigating LLMs for stance detection across Twitter datasets',         u:'https://arxiv.org/abs/2309.13734' },
  '2508.04848': { t:'RL fine-tuning of LLMs under non-ideal inference scenarios',             u:'https://arxiv.org/abs/2508.04848' },
  '2501.05032': { t:'DPO for human-like response generation in LLMs',                         u:'https://arxiv.org/abs/2501.05032' },
  '2403.00946': { t:'Fine-tuning with high dropout for out-of-distribution generalization',   u:'https://arxiv.org/abs/2403.00946' },
  '2412.16117': { t:'Training-free video token pruning for efficient video understanding',    u:'https://arxiv.org/abs/2412.16117' },
  '2310.03059': { t:'Point-PEFT: Parameter-efficient fine-tuning for 3D point cloud models', u:'https://arxiv.org/abs/2310.03059' },
  '2602.08239': { t:'Linearized fine-tuning and spectral perturbation bounds via NTK',        u:'https://arxiv.org/abs/2602.08239' },
};

// ══ 3. GRAPH DATA — canonical source ══════════════════════════════════════════

const GRAPH_RAW = {
  papers: {
    'arxiv:2602.08239': { core_methodology: 'Linearized fine-tuning with explicit inductive bias using NTK to predict performance.',         year: '2026', pagerank: 0.94 },
    'arxiv:2312.10793': { core_methodology: 'Comprehensive experimentation across combinations of instruction datasets.',                     year: '2023', pagerank: 0.61 },
    'arxiv:2402.11651': { core_methodology: 'Fine-tuning LLMs with a mix of positive and negative examples (NAT paradigm).',                 year: '2024', pagerank: 0.58 },
    'arxiv:2110.06500': { core_methodology: 'Advanced parameter-efficient methods for private fine-tuning of large models.',                  year: '2021', pagerank: 0.89 },
    'arxiv:2309.13734': { core_methodology: 'Evaluating the stance detection task using LLMs across 6 Twitter datasets.',                    year: '2023', pagerank: 0.42 },
    'arxiv:2508.04848': { core_methodology: 'RL fine-tuning with policy gradient algorithms under non-ideal scenarios.',                      year: '2025', pagerank: 0.77 },
    'arxiv:2501.05032': { core_methodology: 'Direct Preference Optimization (DPO) technique for human-like response generation.',            year: '2025', pagerank: 0.66 },
    'arxiv:2403.00946': { core_methodology: 'Fine-tuning a large pre-trained model with very high dropout rates.',                           year: '2024', pagerank: 0.38 },
    'arxiv:2412.16117': { core_methodology: 'Training-free approach for pruning video tokens to achieve efficient video understanding.',      year: '2024', pagerank: 0.55 },
    'arxiv:2310.03059': { core_methodology: 'Point-PEFT framework for 3D pre-trained models with geometry-aware adapters.',                  year: '2023', pagerank: 0.49 },
  },
  graph_edges: [
    { source_paper: 'arxiv:2602.08239', target_paper: 'arxiv:2110.06500', relationship_type: 'EXTENDS',     relationship_context: 'Explores advanced parameter-efficient methods beyond standard PEFT.' },
    { source_paper: 'arxiv:2602.08239', target_paper: 'arxiv:2508.04848', relationship_type: 'CONTRADICTS', relationship_context: 'Uses deterministic NTK bounds instead of stochastic RL policy gradients.' },
    { source_paper: 'arxiv:2110.06500', target_paper: 'arxiv:2508.04848', relationship_type: 'OUTPERFORMS', relationship_context: 'Maintains privacy bounds better under non-ideal inference scenarios.' },
    { source_paper: 'arxiv:2312.10793', target_paper: 'arxiv:2510.07037', relationship_type: 'EXTENDS',     relationship_context: 'Extends the scope by covering more instruction combinations.' },
    { source_paper: 'arxiv:2312.10793', target_paper: 'arxiv:2511.21285', relationship_type: 'OUTPERFORMS', relationship_context: 'Achieves higher alignment evaluation scores.' },
    { source_paper: 'arxiv:2402.11651', target_paper: 'arxiv:2508.04848', relationship_type: 'EXTENDS',     relationship_context: 'Extends negative-aware tuning into policy gradient spaces.' },
    { source_paper: 'arxiv:2402.11651', target_paper: 'arxiv:2402.14800', relationship_type: 'CONTRADICTS', relationship_context: 'Rejects standard SFT assumptions by utilizing failed trajectory data.' },
    { source_paper: 'arxiv:2110.06500', target_paper: 'arxiv:2602.08239', relationship_type: 'CONTRADICTS', relationship_context: 'Shows conflict in parameter efficiency scaling laws.' },
    { source_paper: 'arxiv:2309.13734', target_paper: 'arxiv:2602.14406', relationship_type: 'EXTENDS',     relationship_context: 'Expands on stance detection using zero-shot prompting.' },
    { source_paper: 'arxiv:2508.04848', target_paper: 'arxiv:2110.06500', relationship_type: 'EXTENDS',     relationship_context: 'Applies RLHF to private parameter-efficient setups.' },
    { source_paper: 'arxiv:2501.05032', target_paper: 'arxiv:2601.11573', relationship_type: 'EXTENDS',     relationship_context: 'Applies DPO tuning specifically to biological and medical datasets.' },
    { source_paper: 'arxiv:2501.05032', target_paper: 'arxiv:2603.06270', relationship_type: 'CONTRADICTS', relationship_context: 'Contradicts structured pruning in favor of preference weights.' },
    { source_paper: 'arxiv:2412.16117', target_paper: 'arxiv:2602.08024', relationship_type: 'EXTENDS',     relationship_context: 'Introduces Tree-based Spatiotemporal Token Merging (TSTM).' },
    { source_paper: 'arxiv:2310.03059', target_paper: 'arxiv:2505.22444', relationship_type: 'EXTENDS',     relationship_context: 'Point-PEFT extends idea with a Geometry-aware Adapter.' },
    { source_paper: 'arxiv:2310.03059', target_paper: 'arxiv:2509.00374', relationship_type: 'OUTPERFORMS', relationship_context: 'Outperforms in direct point cloud processing efficiency.' },
  ],
};

// Compute initial nodeCount / edgeCount and push into AppState
(function seedGraphCounts() {
  const seen = new Set();
  GRAPH_RAW.graph_edges.forEach(function (e) {
    seen.add(e.source_paper);
    seen.add(e.target_paper);
  });
  AppState.set({ nodeCount: seen.size, edgeCount: GRAPH_RAW.graph_edges.length });
}());

// Relationship colour palette
const RG_COLORS = {
  EXTENDS:     { bg: '#ECFDF5', txt: '#059669', stroke: '#34d399' },
  CONTRADICTS: { bg: '#FCEBEB', txt: '#E24B4A', stroke: '#f87171' },
  OUTPERFORMS: { bg: '#EFF6FF', txt: '#2563EB', stroke: '#60a5fa' },
  REPLICATES:  { bg: '#ede9fe', txt: '#6d28d9', stroke: '#a78bfa' },
  RELATED:     { bg: '#f0f2f6', txt: '#4a5270', stroke: '#94a3b8' },
};

// ══ 4. SSE BRIDGE — /api/research/stream ══════════════════════════════════════
// Simulates the SSE stream. In production, replace the simulation with a real
// EventSource connected to /api/research/stream. The handler shape is identical.

(function initSSE() {
  // ── Real EventSource (uncomment when backend is live) ──────────────────────
  // const es = new EventSource('/api/research/stream');
  // es.addEventListener('batch', function (e) { handleSSEBatch(JSON.parse(e.data)); });
  // es.addEventListener('error', function () { console.warn('[SSE] stream error, retrying…'); });
  // ──────────────────────────────────────────────────────────────────────────

  // ── Simulation: fires a batch of 2 papers every 12 s ──────────────────────
  let batchIndex = 0;
  const BATCHES = [
    { papers: 2, citations: 4, contradictions: 1, gaps: 2 },
    { papers: 2, citations: 3, contradictions: 0, gaps: 1 },
    { papers: 2, citations: 5, contradictions: 1, gaps: 3 },
  ];

  function simulateBatch() {
    if (batchIndex >= BATCHES.length) return;
    const b = BATCHES[batchIndex++];
    handleSSEBatch(b);
    if (batchIndex < BATCHES.length) setTimeout(simulateBatch, 12000);
  }

  // Kick off first simulated batch after 12 s
  setTimeout(simulateBatch, 12000);
}());

// ── SSE batch handler — updates AppState, triggers reflow ─────────────────────
function handleSSEBatch(batch) {
  // 1. Show "Syncing…" state immediately
  AppState.set({ syncing: true, lastBatch: new Date().toISOString() });

  // 2. After 900 ms "sync" window, commit new values and clear syncing flag
  setTimeout(function () {
    AppState.set({
      papers:         AppState.get('papers')         + (batch.papers        || 0),
      citations:      AppState.get('citations')      + (batch.citations     || 0),
      contradictions: AppState.get('contradictions') + (batch.contradictions|| 0),
      gaps:           AppState.get('gaps')           + (batch.gaps          || 0),
      syncing:        false,
    });
  }, 900);
}

// ══ 5. HELPERS ════════════════════════════════════════════════════════════════

function ext(s) {
  s = s || 9;
  return `<svg width="${s}" height="${s}" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M2 10L10 2M6 2h4v4"/></svg>`;
}

function openP(ids) {
  if (!ids || !ids.length) return;
  if (ids.length === 1) { window.open(PM[ids[0]]?.u || 'https://arxiv.org/abs/' + ids[0], '_blank'); return; }
  showModal(ids);
}
function showModal(ids, label) {
  document.getElementById('modal-title').textContent = (label || ids.length + ' papers') + ' — source papers';
  document.getElementById('modal-body').innerHTML = ids.map(function (id) {
    const m = PM[id] || { t: id, u: 'https://arxiv.org/abs/' + id };
    return `<div class="m-row"><span class="m-pid">${id}</span><span class="m-ptitle">${m.t}</span><a class="m-link" href="${m.u}" target="_blank" rel="noopener">Open ${ext(9)}</a></div>`;
  }).join('');
  document.getElementById('modal').classList.add('active');
}
function closeModal()     { document.getElementById('modal').classList.remove('active'); }
function handleBD(e)      { if (e.target === document.getElementById('modal')) closeModal(); }
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

function iconSVG(t, s) {
  if (t === 'check') return `<svg width="13" height="13" viewBox="0 0 14 14" fill="none" stroke="${s}" stroke-width="1.6" stroke-linecap="round"><polyline points="2,7 5,10 12,3"/></svg>`;
  if (t === 'x')     return `<svg width="13" height="13" viewBox="0 0 14 14" fill="none" stroke="${s}" stroke-width="1.6" stroke-linecap="round"><line x1="3" y1="3" x2="11" y2="11"/><line x1="11" y1="3" x2="3" y2="11"/></svg>`;
  if (t === 'up')    return `<svg width="13" height="13" viewBox="0 0 14 14" fill="none" stroke="${s}" stroke-width="1.6" stroke-linecap="round"><line x1="7" y1="2" x2="7" y2="12"/><polyline points="3,6 7,2 11,6"/></svg>`;
  if (t === 'down')  return `<svg width="13" height="13" viewBox="0 0 14 14" fill="none" stroke="${s}" stroke-width="1.6" stroke-linecap="round"><polyline points="2,4 7,9 12,4"/><line x1="7" y1="9" x2="7" y2="12"/></svg>`;
}

// ══ 6. PANEL SWITCHING ════════════════════════════════════════════════════════

const PAGE_META = {
  methodology: { title:'Evolution of Methodologies', sub:'LLM Fine-tuning &amp; PEFT Literature &nbsp;·&nbsp; 2021 – 2026', badges:'<span class="tb-badge">10 papers</span><span class="tb-badge amber">5 method families</span>' },
  openq:       { title:'Open Questions',             sub:'Questions the literature has circled but never directly answered',  badges:'<span class="tb-badge amber">15 gaps identified</span><span class="tb-badge">5 themes</span>' },
  dashboard:   { title:'Dashboard',                  sub:'Research Intelligence overview &nbsp;·&nbsp; LLM Fine-tuning &amp; PEFT', badges:'<span class="tb-badge">10 papers</span>' },
  graph:       { title:'Research Graph',             sub:'Force-directed knowledge graph · 2021 – 2026', badges:'<span class="tb-badge" id="tb-edge-count">36 citation edges</span>' },
  citation:    { title:'Citation Trail Explorer',    sub:'Hierarchical lineage of PEFT methodologies · 2021 – 2026', badges:'<span class="tb-badge">10 papers</span><span class="tb-badge amber">14 edges</span>' },
  papers:      { title:'Papers',                     sub:'Full corpus of analyzed papers', badges:'<span class="tb-badge">10 papers analyzed</span>' },
  ml:          { title:'ML Predictions',             sub:'Model-level intelligence &amp; future trend forecasting',          badges:'',   stub:{ icon:'wave',   label:'ML Predictions', desc:'Trend forecasting and model predictions — connect your ML component here.' } },
  query:       { title:'Oracle Query',               sub:'Ask anything about the research corpus',                           badges:'',   stub:{ icon:'search', label:'Oracle Query',   desc:'Natural language querying of your research corpus — connect your query component here.' } },
};

const STUB_ICONS = {
  graph:  '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"><circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="19" r="2.5"/><circle cx="19" cy="19" r="2.5"/><line x1="12" y1="7.5" x2="6.5" y2="16.5"/><line x1="12" y1="7.5" x2="17.5" y2="16.5"/><line x1="7.5" y1="19" x2="16.5" y2="19"/></svg>',
  doc:    '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="9" y1="7" x2="15" y2="7"/><line x1="9" y1="11" x2="15" y2="11"/><line x1="9" y1="15" x2="12" y2="15"/></svg>',
  wave:   '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M7 12 Q9 8 11 12 Q13 16 15 12 Q17 8 17 12"/></svg>',
  search: '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="21" y2="21"/></svg>',
};

let chartsBuilt = { dashboard: false, methodology: false, openq: false, papers: false };

function switchPanel(name) {
  document.querySelectorAll('.panel').forEach(function (p) { p.classList.remove('active'); });
  document.querySelectorAll('.nav-item').forEach(function (n) { n.classList.remove('active', 'active-amber'); });

  const meta = PAGE_META[name] || PAGE_META.dashboard;
  document.getElementById('page-title').innerHTML  = meta.title;
  document.getElementById('page-sub').innerHTML    = meta.sub;
  document.getElementById('page-badges').innerHTML = meta.badges;

  const panel = document.getElementById('panel-' + name);
  if (!panel) return;
  panel.classList.add('active');

  const navEl = document.getElementById('nav-' + name);
  if (navEl) navEl.classList.add(name === 'openq' ? 'active-amber' : 'active');

  // Stub panels render on first visit only (panels with pre-built content are skipped)
  if (meta.stub && panel.innerHTML.trim() === '') {
    panel.innerHTML = `
      <div class="stub-wrap">
        <div class="stub-icon">${STUB_ICONS[meta.stub.icon] || ''}</div>
        <div class="stub-label">${meta.stub.label}</div>
        <div class="stub-desc">${meta.stub.desc}</div>
        <div class="stub-hint">
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><polyline points="3,8 8,3 13,8"/><line x1="8" y1="3" x2="8" y2="13"/></svg>
          Replace the <code>panel-${name}</code> div contents with your component
        </div>
      </div>`;
  }

  if (name === 'dashboard' && !chartsBuilt.dashboard) {
    chartsBuilt.dashboard = true;
    setTimeout(buildDashboard, 60);
  }
  if (name === 'methodology' && !chartsBuilt.methodology) {
    chartsBuilt.methodology = true;
    setTimeout(buildMethodologyCharts, 60);
  }
  if (name === 'openq' && !chartsBuilt.openq) {
    chartsBuilt.openq = true;
    setTimeout(buildOQCharts, 60);
  }
  if (name === 'graph') {
    // 80 ms delay ensures panel is display:flex before D3 reads container dims
    setTimeout(initResearchGraph, 80);
  }
  if (name === 'citation') {
    setTimeout(initCitationTrail, 80);
  }
  if (name === 'papers' && !chartsBuilt.papers) {
    chartsBuilt.papers = true;
    setTimeout(function () { PapersPanel.build(); }, 60);
  }
}

// ══ 7. DASHBOARD ══════════════════════════════════════════════════════════════

// ── Reactive counter element mapping ──────────────────────────────────────────
const COUNTER_MAP = {
  papers:          'cnt-papers',
  citations:       'cnt-citations',
  contradictions:  'cnt-contradictions',
  gaps:            'cnt-gaps',
  foundational:    'cnt-foundational',
  methods:         'cnt-methods',
};

// Tracks running animation frame IDs so we can cancel & restart on fast updates
const _counterRAFs = {};
let   _prevValues  = {};

function animateCounter(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  if (_counterRAFs[id]) cancelAnimationFrame(_counterRAFs[id]);
  const from  = _prevValues[id] !== undefined ? _prevValues[id] : 0;
  const dur   = 900;
  const start = performance.now();
  function step(now) {
    const p = Math.min((now - start) / dur, 1);
    const e = 1 - Math.pow(1 - p, 3);       // ease-out-cubic
    el.textContent = Math.round(from + (target - from) * e);
    if (p < 1) { _counterRAFs[id] = requestAnimationFrame(step); }
    else        { _prevValues[id] = target; delete _counterRAFs[id]; }
  }
  _counterRAFs[id] = requestAnimationFrame(step);
}

// ── Syncing banner ────────────────────────────────────────────────────────────
function setSyncBanner(syncing) {
  let banner = document.getElementById('db-sync-banner');
  if (!banner) return;
  if (syncing) {
    banner.classList.add('db-sync-active');
    banner.innerHTML = `<span class="db-sync-dot"></span>Syncing new batch…`;
  } else {
    banner.classList.remove('db-sync-active');
    banner.innerHTML = `<span class="db-sync-check">✓</span>All metrics up to date`;
    setTimeout(function () {
      if (banner) banner.innerHTML = '';
    }, 3000);
  }
}

// ── AppState subscriber — reacts to every state change ────────────────────────
AppState.subscribe(function (state) {
  // Update counters only if dashboard panel is built
  if (!chartsBuilt.dashboard) return;

  Object.keys(COUNTER_MAP).forEach(function (key) {
    if (state[key] !== undefined) animateCounter(COUNTER_MAP[key], state[key]);
  });

  // Update stat bar widths reactively
  const pBar = document.querySelector('#cnt-papers')?.closest('.db-stat-card')?.querySelector('.db-stat-bar-fill');
  if (pBar) pBar.style.width = Math.min(100, (state.papers / 20) * 100) + '%';

  // Syncing banner
  setSyncBanner(state.syncing);

  // Topbar edge-count badge (graph panel)
  const eBadge = document.getElementById('tb-edge-count');
  if (eBadge) eBadge.textContent = state.edgeCount + ' citation edges';

  // Update mini-graph footer stats
  const gfNodes = document.getElementById('gf-node-count');
  const gfEdges = document.getElementById('gf-edge-count');
  if (gfNodes) gfNodes.textContent = state.nodeCount;
  if (gfEdges) gfEdges.textContent = state.edgeCount;
});

// ── Dashboard build ───────────────────────────────────────────────────────────
// ── Dashboard build ───────────────────────────────────────────────────────────
function buildDashboard() {
  const s = AppState.getAll();
  Object.keys(COUNTER_MAP).forEach(function (key) {
    animateCounter(COUNTER_MAP[key], s[key] || 0);
  });
  
  // FIX: Only inject static dummy data if we DIDN'T just load dynamic API data
  if (!localStorage.getItem('oracle_data')) {
      buildTopPapers();
      buildGapsList();
  }
  
  setTimeout(buildDashboardMiniGraph, 160);
}

// ══ 8. METHODOLOGY DATA & CHARTS ══════════════════════════════════════════════

const METHODS = [
  { label:'PEFT / LoRA',        color:'#2563EB', values:[30,55,65,72,78,82], papers:['2110.06500'] },
  { label:'RL Fine-tuning',     color:'#059669', values:[0,5,18,32,62,70],   papers:['2508.04848'] },
  { label:'Instruction tuning', color:'#BA7517', values:[5,20,48,38,25,18],  papers:['2312.10793'] },
  { label:'Linearized / NTK',   color:'#6d28d9', values:[0,0,5,12,25,55],    papers:['2602.08239'] },
  { label:'Token pruning',      color:'#0f6e56', values:[0,0,8,28,38,42],    papers:['2412.16117'] },
];
const YEARS = [2021,2022,2023,2024,2025,2026];

const HM = {
  methods:['PEFT / LoRA','RL Fine-tuning','Instruct Tune','Linearized FT','Token Pruning','NAT','DP-PEFT','DPO'],
  papers: [['2110.06500'],['2508.04848'],['2312.10793'],['2602.08239'],['2412.16117'],['2402.11651'],['2110.06500'],['2501.05032']],
  years:  [2021,2022,2023,2024,2025,2026],
  values: [
    [.30,.40,.55,.65,.72,.80],[.00,.05,.18,.32,.62,.70],
    [.05,.20,.48,.38,.25,.18],[.00,.00,.05,.12,.25,.55],
    [.00,.00,.08,.28,.38,.42],[.00,.00,.10,.45,.40,.32],
    [.35,.30,.28,.22,.20,.18],[.00,.00,.05,.25,.60,.65],
  ]
};
const VEL = {
  labels:['PEFT/LoRA','RL FT','Instruct','NTK','Prune','NAT','DP-PEFT','DPO'],
  data:  [12,22,-12,30,8,-5,-8,25],
  papers:[['2110.06500'],['2508.04848'],['2312.10793'],['2602.08239'],['2412.16117'],['2402.11651'],['2110.06500'],['2501.05032']],
};
const LIFECYCLE = [
  { icon:'check',iconBg:'var(--green-lt)',iconS:'#059669',cntBg:'var(--green-lt)',cntC:'var(--green)',title:'Rising — gaining adoption',count:4, rows:[
    {n:'RL Fine-tuning / Policy Gradient',y:'2025→',w:82,c:'#059669',p:['2508.04848']},
    {n:'Direct Preference Optimization (DPO)',y:'2025→',w:70,c:'#059669',p:['2501.05032']},
    {n:'Linearized Fine-tuning (NTK)',y:'2026→',w:55,c:'#059669',p:['2602.08239']},
    {n:'3D Point Cloud PEFT',y:'2023→',w:48,c:'#059669',p:['2310.03059']},
  ]},
  { icon:'x',iconBg:'var(--red-lt)',iconS:'#E24B4A',cntBg:'var(--red-lt)',cntC:'var(--red)',title:'Declining — post-peak',count:3, rows:[
    {n:'Naive Full Fine-tuning (no PEFT)',y:'2021↓',w:72,c:'var(--red)',p:['2110.06500','2312.10793']},
    {n:'Instruction tuning (all-mix)',y:'2023↓',w:55,c:'var(--red)',p:['2312.10793']},
    {n:'High-dropout regularization',y:'2024↓',w:38,c:'var(--amber)',p:['2403.00946']},
  ]},
  { icon:'up',iconBg:'var(--blue-lt)',iconS:'#2563EB',cntBg:'var(--blue-lt)',cntC:'var(--blue)',title:'Introduced — new entrants',count:5, rows:[
    {n:'PEFT / LoRA-style methods',y:'2021',w:90,c:'var(--blue)',p:['2110.06500']},
    {n:'Negative-aware training (NAT)',y:'2024',w:62,c:'var(--blue)',p:['2402.11651']},
    {n:'Training-free video token pruning',y:'2024',w:50,c:'var(--blue)',p:['2412.16117']},
    {n:'Private fine-tuning (DP-PEFT)',y:'2021',w:45,c:'var(--blue)',p:['2110.06500']},
    {n:'LLM stance detection (zero-shot)',y:'2023',w:35,c:'var(--purple)',p:['2309.13734']},
  ]},
  { icon:'down',iconBg:'var(--purple-lt)',iconS:'#6d28d9',cntBg:'var(--purple-lt)',cntC:'var(--purple)',title:'Improved — evolved variants',count:3, rows:[
    {n:'PEFT → Geometry-aware PEFT (3D)',y:'23→24',w:74,c:'var(--purple)',p:['2310.03059']},
    {n:'SFT → Negative-aware training',y:'23→24',w:68,c:'var(--purple)',p:['2402.11651']},
    {n:'Full FT → LoRA-style sparse FT',y:'21→26',w:85,c:'var(--purple)',p:['2110.06500','2602.08239']},
  ]},
];
const CONTESTED = [
  {title:'Private FT (DP-PEFT) vs. Standard PEFT',body:'DP noise grows with model size, undermining the efficiency PEFT was designed to provide. No consensus on which to prioritize.',papers:['2110.06500'],conf:.80,yr:'2021'},
  {title:'Negative-aware training (NAT) vs. Standard SFT',body:'NAT uses failed trajectories as signal, contradicting the SFT assumption that only positive examples should be trained on.',papers:['2402.11651','2508.04848'],conf:.70,yr:'2024'},
  {title:'RL fine-tuning vs. Pure SFT for reasoning',body:'RL-tuned models show significant decline under non-ideal conditions while SFT stays stable — casting doubt on RL as the universal solution.',papers:['2508.04848'],conf:.75,yr:'2025'},
  {title:'Instruction mix diversity vs. task-specific tuning',body:'Combining all instruction types can negatively impact conversational abilities, contesting the "more diverse = better" assumption.',papers:['2312.10793'],conf:.65,yr:'2023'},
];
const TL_DATA = [
  {year:2021,trend:'Shift towards parameter-efficient methods',color:'#2563EB', methods:[{n:'PEFT / LoRA introduced',bg:'#dbeafe',tc:'#1e40af',p:['2110.06500']},{n:'Private FT (DP-PEFT)',bg:'#ede9fe',tc:'#5b21b6',p:['2110.06500']}]},
  {year:2022,trend:'Consolidation — LoRA variants dominate',color:'#6d28d9',   methods:[{n:'LoRA scaling studies',bg:'#ede9fe',tc:'#5b21b6',p:['2110.06500']},{n:'PEFT on RoBERTa-Large',bg:'#dbeafe',tc:'#1e40af',p:['2110.06500']}]},
  {year:2023,trend:'Instruction tuning peaks, Point-PEFT emerges',color:'#BA7517', methods:[{n:'Instruction dataset mixing',bg:'#fef3c7',tc:'#92400e',p:['2312.10793']},{n:'Point-PEFT (3D clouds)',bg:'#d1fae5',tc:'#065f46',p:['2310.03059']},{n:'LLM stance detection',bg:'#ede9fe',tc:'#5b21b6',p:['2309.13734']}]},
  {year:2024,trend:'Negative examples & token compression introduced',color:'#0f6e56', methods:[{n:'Negative-aware training',bg:'#d1fae5',tc:'#065f46',p:['2402.11651']},{n:'High-dropout fine-tuning',bg:'#fef3c7',tc:'#92400e',p:['2403.00946']},{n:'Video token pruning',bg:'#dbeafe',tc:'#1e40af',p:['2412.16117']}]},
  {year:2025,trend:'RL fine-tuning & DPO rise, SFT contested',color:'#059669', methods:[{n:'RL + policy gradient FT',bg:'#d1fae5',tc:'#065f46',p:['2508.04848']},{n:'Direct Preference Optimization',bg:'#d1fae5',tc:'#065f46',p:['2501.05032']},{n:'Non-ideal scenario testing',bg:'#fee2e2',tc:'#991b1b',p:['2508.04848']}]},
  {year:2026,trend:'Linearized FT & NTK theory enters mainstream',color:'#6d28d9', methods:[{n:'Linearized fine-tuning (NTK)',bg:'#ede9fe',tc:'#5b21b6',p:['2602.08239']},{n:'Spectral PEFT bounds',bg:'#dbeafe',tc:'#1e40af',p:['2602.08239']}]},
];

function buildMethodologyCharts() {
  document.getElementById('line-legend').innerHTML = METHODS.map(function (m) {
    return `<span class="leg-chip" onclick="openP(${JSON.stringify(m.papers)})" title="Open paper for ${m.label}">
      <span class="leg-swatch" style="background:${m.color};"></span>${m.label} ${ext(9)}
    </span>`;
  }).join('');

  const ac = new Chart(document.getElementById('adoption-chart'), {
    type:'line',
    data:{ labels:YEARS, datasets: METHODS.map(function (m) { return {
      label:m.label, data:m.values, borderColor:m.color, backgroundColor:m.color+'18',
      borderWidth:2, pointRadius:5, pointHoverRadius:8,
      pointBackgroundColor:m.color, pointBorderColor:'#fff', pointBorderWidth:2,
      tension:0.4, fill:true, _papers:m.papers
    };})},
    options:{
      responsive:true, maintainAspectRatio:false, animation:{duration:900},
      interaction:{mode:'nearest',intersect:true},
      plugins:{legend:{display:false},tooltip:{callbacks:{
        title:function(ctx){ return ctx[0].dataset.label + ' · ' + ctx[0].label; },
        label:function(ctx){ return ' ' + Math.round(ctx.parsed.y) + '% adoption — click to open paper'; }
      }}},
      scales:{
        x:{grid:{color:'#f1f5f9'},ticks:{font:{size:11},color:'#94a3b8'},border:{display:false}},
        y:{grid:{color:'#f1f5f9'},ticks:{callback:function(v){return v+'%';},font:{size:10},color:'#94a3b8'},border:{display:false},max:100,min:0}
      },
      onClick:function(_,els){ if(els.length) openP(ac.data.datasets[els[0].datasetIndex]._papers); }
    }
  });

  (function heatmap(){
    const canvas=document.getElementById('heatmap-canvas');
    const wrap=canvas.parentElement;
    let hov=-1,PAD,cw,ch;
    function draw(){
      const W=wrap.clientWidth,H=256,dpr=window.devicePixelRatio||1;
      canvas.width=W*dpr;canvas.height=H*dpr;
      canvas.style.width=W+'px';canvas.style.height=H+'px';
      const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);
      PAD={top:8,right:12,bottom:30,left:104};
      const pw=W-PAD.left-PAD.right,ph=H-PAD.top-PAD.bottom;
      cw=pw/HM.years.length;ch=ph/HM.methods.length;
      HM.values.forEach(function(row,ri){
        const isH=hov===ri;
        row.forEach(function(val,ci){
          const x=PAD.left+ci*cw,y=PAD.top+ri*ch;
          const r2=Math.round(250-val*(250-99)),g2=Math.round(238-val*(238-56)),b2=Math.round(218-val*(218-6));
          ctx.fillStyle=isH?`rgb(${r2},${g2},${b2})`:`rgba(${r2},${g2},${b2},.82)`;
          ctx.beginPath();ctx.roundRect(x+2,y+2,cw-4,ch-4,4);ctx.fill();
          if(val>0.25){
            ctx.fillStyle=val>0.6?'#fff':'#1e293b';
            ctx.font=`${isH?'600':'500'} ${Math.round(cw*0.2)+7}px DM Mono,monospace`;
            ctx.textAlign='center';ctx.textBaseline='middle';
            ctx.fillText(Math.round(val*100)+'%',x+cw/2,y+ch/2);
          }
        });
        ctx.fillStyle=isH?'#0d1226':'#4a5270';ctx.font=`${isH?'600':'400'} 11px DM Sans,sans-serif`;
        ctx.textAlign='right';ctx.textBaseline='middle';
        ctx.fillText(HM.methods[ri],PAD.left-6,PAD.top+ri*ch+ch/2);
      });
      HM.years.forEach(function(yr,i){
        ctx.fillStyle='#94a3b8';ctx.font='10px DM Mono,monospace';
        ctx.textAlign='center';ctx.textBaseline='top';
        ctx.fillText(yr,PAD.left+i*cw+cw/2,H-PAD.bottom+6);
      });
    }
    draw();
    canvas.addEventListener('mousemove',function(e){
      const r=canvas.getBoundingClientRect();
      const mx=e.clientX-r.left,my=e.clientY-r.top;
      const ri=Math.floor((my-PAD.top)/ch);
      const ci=Math.floor((mx-PAD.left)/cw);
      if(ri>=0&&ri<HM.methods.length&&ci>=0&&ci<HM.years.length){
        canvas.style.cursor='pointer';
        if(hov!==ri){hov=ri;draw();}
      } else { if(hov!==-1){hov=-1;draw();}canvas.style.cursor='default'; }
    });
    canvas.addEventListener('mouseleave',function(){if(hov!==-1){hov=-1;draw();}canvas.style.cursor='default';});
    canvas.addEventListener('click',function(e){
      const r=canvas.getBoundingClientRect();
      const ri=Math.floor((e.clientY-r.top-PAD.top)/ch);
      if(ri>=0&&ri<HM.papers.length)openP(HM.papers[ri]);
    });
    window.addEventListener('resize',draw);
  }());

  const vc=new Chart(document.getElementById('velocity-chart'),{
    type:'bar',
    data:{labels:VEL.labels,datasets:[{
      data:VEL.data,
      backgroundColor:VEL.data.map(function(v){return v>0?'#059669':v<0?'#E24B4A':'#2563EB';}),
      borderRadius:5,barPercentage:.65
    }]},
    options:{
      responsive:true,maintainAspectRatio:false,animation:{duration:700},
      plugins:{legend:{display:false},tooltip:{callbacks:{label:function(ctx){return ' '+ctx.parsed.y+'% YoY';},title:function(ctx){return ctx[0].label+' velocity';} }}},
      scales:{
        x:{grid:{display:false},ticks:{font:{size:10},color:'#94a3b8'},border:{display:false}},
        y:{grid:{color:'#f1f5f9'},ticks:{callback:function(v){return v+'%';},font:{size:10},color:'#94a3b8'},border:{display:false}}
      },
      onClick:function(_,els){if(els.length)openP(VEL.papers[els[0].index]);}
    }
  });

  const sg=document.getElementById('status-grid');
  if(sg) sg.innerHTML=LIFECYCLE.map(function(lc){
    return `<div class="status-card">
      <div class="status-card-head">
        <div class="status-icon" style="background:${lc.iconBg};">${iconSVG(lc.icon,lc.iconS)}</div>
        <span class="status-card-title">${lc.title}</span>
        <span class="status-card-count" style="background:${lc.cntBg};color:${lc.cntC};">${lc.count}</span>
      </div>
      ${lc.rows.map(function(r){return `<div class="method-row" onclick="openP(${JSON.stringify(r.p)})">
        <span class="m-dot" style="background:${r.c};"></span>
        <span class="m-name">${r.n}</span>
        <span class="m-year">${r.y}</span>
        <div class="m-bar-wrap"><div class="m-bar-fill" style="background:${r.c};width:${r.w}%;"></div></div>
        <span class="m-hint">${ext(9)}</span>
      </div>`;}).join('')}
    </div>`;
  }).join('');

  const cl=document.getElementById('contested-list');
  if(cl) cl.innerHTML=CONTESTED.map(function(c){
    const chips=c.papers.map(function(p){return `<a class="paper-chip" href="${PM[p]?.u}" target="_blank" rel="noopener" onclick="event.stopPropagation();">${ext(9)} ${p}</a>`;}).join('');
    return `<div class="contested-card">
      <div class="c-head"><span class="c-title">${c.title}</span><span class="c-vs">CONTESTED</span><span class="c-yr">${c.yr}</span></div>
      <div class="c-body">${c.body}</div>
      <div class="c-footer">${chips}
        <div class="conf-wrap"><div class="conf-bar"><div class="conf-fill" style="width:${c.conf*100}%;"></div></div>
        <span style="font-size:10px;color:var(--text3);">${Math.round(c.conf*100)}% confidence</span></div>
      </div>
    </div>`;
  }).join('');

  const tl=document.getElementById('tl-cards');
  if(tl) { tl.innerHTML='<div class="tl-line"></div>'+TL_DATA.map(function(y){
    return `<div class="tl-item">
      <div class="tl-dot" style="background:${y.color};"></div>
      <div class="tl-card">
        <div class="tl-head"><span class="tl-year" style="color:${y.color};">${y.year}</span><span class="tl-trend">${y.trend}</span></div>
        <div class="tl-pills">${y.methods.map(function(m){return `<span class="tl-pill" style="background:${m.bg};color:${m.tc};border-color:${m.bg};" onclick="openP(${JSON.stringify(m.p)})">${m.n} ${ext(9)}</span>`;}).join('')}</div>
      </div>
    </div>`;
  }).join(''); }
}

// ══ 9. OPEN QUESTIONS DATA & CHARTS ═══════════════════════════════════════════

const OQ_THEMES = [
  {id:'theory',label:'Theory & Generalisation',ct:3,color:'#7F77DD'},
  {id:'perf',  label:'Performance Reliability', ct:4,color:'#E24B4A'},
  {id:'eff',   label:'Efficiency & Scalability', ct:4,color:'#378ADD'},
  {id:'priv',  label:'Privacy & Security',      ct:2,color:'#1D9E75'},
  {id:'eth',   label:'Ethics & Bias',            ct:2,color:'#BA7517'},
];
const OQ_QUESTIONS = [
  {theme:'theory',text:'Why does fine-tuning large networks on small datasets remain intrinsically linear — and what does this imply for generalisation?',papers:['2403.00946'],year:2024,void:83},
  {theme:'theory',text:'Under what architectural conditions does fine-tuning operate in the NTK regime?',papers:['2602.08239'],year:2026,void:70},
  {theme:'theory',text:'No principled theory explains when negative training examples help vs. hurt alignment.',papers:['2402.11651'],year:2024,void:65},
  {theme:'perf',  text:'Fine-tuning does not necessarily lead to better performance — no reliable predictor of when it will help.',papers:['2309.13734','2508.04848'],year:2023,void:78},
  {theme:'perf',  text:'Performance varies strongly with input context and prompt design — no consistent optimal strategy identified.',papers:['2309.13734'],year:2023,void:65},
  {theme:'perf',  text:'Significant performance decline in advanced reasoning under non-ideal inference conditions (noisy, filtered, summarised inputs).',papers:['2508.04848'],year:2025,void:87},
  {theme:'perf',  text:'Remediation strategies for non-ideal RL fine-tuning scenarios are entirely unexplored.',papers:['2508.04848'],year:2025,void:84},
  {theme:'eff',   text:'Prior video methods require full visual token encoding during prefill — a prohibitive cost with no principled alternative.',papers:['2412.16117'],year:2024,void:71},
  {theme:'eff',   text:'Improving video token pruning while preserving question-relevant information remains an open engineering and theoretical problem.',papers:['2412.16117'],year:2024,void:68},
  {theme:'eff',   text:'PEFT methods for 3D pre-trained point-cloud models are severely under-explored relative to 2D and text domains.',papers:['2310.03059'],year:2023,void:80},
  {theme:'eff',   text:'Effectiveness of geometry-aware PEFT in diverse downstream 3D tasks beyond classification is unknown.',papers:['2310.03059','2602.08239'],year:2023,void:73},
  {theme:'priv',  text:'DP noise magnitude grows with model size — no scalable solution exists for large-model private fine-tuning.',papers:['2110.06500'],year:2021,void:89},
  {theme:'priv',  text:'Parameter-efficiency in the context of private learning is theoretically and empirically under-studied.',papers:['2110.06500'],year:2021,void:85},
  {theme:'eth',   text:'Ethical implications and biases introduced when LLMs respond with human-like attributes remain unaddressed.',papers:['2501.05032'],year:2025,void:62},
  {theme:'eth',   text:'No reliable method exists for making LLM responses feel natural without introducing unintended persona biases.',papers:['2501.05032'],year:2025,void:45},
];
const OQ_TL_YEARS = [
  {year:2021,qs:2,color:'#7F77DD'},{year:2023,qs:5,color:'#E24B4A'},
  {year:2024,qs:3,color:'#378ADD'},{year:2025,qs:3,color:'#BA7517'},{year:2026,qs:2,color:'#1D9E75'},
];

function buildOQCharts() {
  document.getElementById('oq-donut-legend').innerHTML = OQ_THEMES.map(function (t) {
    return `<span style="display:flex;align-items:center;gap:4px;font-size:11px;color:var(--text2);">
      <span style="width:9px;height:9px;border-radius:50%;background:${t.color};flex-shrink:0;"></span>
      ${t.label.split(' ')[0]} (${t.ct})
    </span>`;
  }).join('');

  new Chart(document.getElementById('oq-donut'),{
    type:'doughnut',
    data:{labels:OQ_THEMES.map(function(t){return t.label;}),datasets:[{data:OQ_THEMES.map(function(t){return t.ct;}),backgroundColor:OQ_THEMES.map(function(t){return t.color;}),borderColor:'#ffffff',borderWidth:3,hoverOffset:6}]},
    options:{responsive:true,maintainAspectRatio:false,cutout:'62%',animation:{duration:700},plugins:{legend:{display:false},tooltip:{callbacks:{label:function(ctx){return ' '+ctx.parsed+' question'+(ctx.parsed>1?'s':'');}}}}}
  });

  const voidData=OQ_THEMES.map(function(t){
    const qs=OQ_QUESTIONS.filter(function(q){return q.theme===t.id;});
    return Math.round(qs.reduce(function(s,q){return s+q.void;},0)/qs.length);
  });
  new Chart(document.getElementById('oq-bar'),{
    type:'bar',
    data:{labels:OQ_THEMES.map(function(t){return t.label.split(' ')[0];}),datasets:[
      {label:'Unexplored',data:voidData,backgroundColor:'#EF9F27',borderRadius:4,barPercentage:.65},
      {label:'Addressed', data:voidData.map(function(v){return 100-v;}),backgroundColor:'#E2E8F0',borderRadius:4,barPercentage:.65}
    ]},
    options:{responsive:true,maintainAspectRatio:false,animation:{duration:700},indexAxis:'y',
      plugins:{legend:{display:false},tooltip:{callbacks:{label:function(ctx){return ' '+ctx.dataset.label+': '+Math.round(ctx.parsed.x)+'%';}}}},
      scales:{x:{stacked:true,max:100,grid:{color:'#f1f5f9'},ticks:{callback:function(v){return v+'%';},font:{size:10},color:'#94a3b8'},border:{display:false}},y:{stacked:true,grid:{display:false},ticks:{font:{size:11},color:'#475569'},border:{display:false}}}}
  });

  document.getElementById('oq-tl').innerHTML = OQ_TL_YEARS.map(function (y) {
    return `<div class="oq-tl-yr">
      <div class="oq-tl-dot" style="background:${y.color};"></div>
      <div class="oq-tl-label">${y.year}</div>
      <div class="oq-tl-qs">${y.qs} Q</div>
    </div>`;
  }).join('');

  let html = '';
  OQ_THEMES.forEach(function (t) {
    const qs = OQ_QUESTIONS.filter(function (q) { return q.theme === t.id; });
    html += `<div class="oq-theme-section">
      <div class="oq-theme-header">
        <div class="oq-theme-stripe" style="background:${t.color};"></div>
        <span class="oq-theme-label">${t.label}</span>
        <span class="oq-theme-ct">${t.ct} question${t.ct > 1 ? 's' : ''}</span>
      </div>`;
    qs.forEach(function (q) {
      const isSingle = q.papers.length === 1;
      const clickFn  = isSingle ? `openP(['${q.papers[0]}'])` : `showModal(${JSON.stringify(q.papers)})`;
      const chips = q.papers.map(function (p) {
        return `<a class="oq-chip" href="${PM[p]?.u||'https://arxiv.org/abs/'+p}" target="_blank" rel="noopener" onclick="event.stopPropagation();" title="${PM[p]?.t}">${ext(9)} ${p}</a>`;
      }).join('');
      html += `<div class="oq-q-card" style="border-left-color:${t.color};" onclick="${clickFn}" title="Click to open source paper">
        <div class="oq-q-text">${q.text}</div>
        <div class="oq-q-footer">
          <span class="oq-year-badge">${q.year}</span>
          ${chips}
          <div class="oq-void-wrap">
            <div class="oq-void-bar"><div class="oq-void-fill" style="width:${q.void}%;"></div></div>
            <span class="oq-void-lbl">${q.void}% void</span>
          </div>
          <span class="oq-open-hint">${isSingle ? 'Open paper' : q.papers.length + ' papers'} ${ext(9)}</span>
        </div>
      </div>`;
    });
    html += '</div>';
  });
  document.getElementById('oq-cards').innerHTML = html;
}

// ══ 10. DASHBOARD STATIC DATA ══════════════════════════════════════════════════

const DB_TOP_PAPERS = [
  { rank:1, id:'2602.08239', title:'Linearized fine-tuning and spectral perturbation bounds via NTK',          year:'2026', venue:'arXiv', cites:4120, pct:100, url:'https://arxiv.org/abs/2602.08239' },
  { rank:2, id:'2110.06500', title:'Parameter-efficient methods for private fine-tuning of large LMs',         year:'2021', venue:'arXiv', cites:3870, pct:94,  url:'https://arxiv.org/abs/2110.06500' },
  { rank:3, id:'2508.04848', title:'RL fine-tuning of LLMs under non-ideal inference scenarios',               year:'2025', venue:'arXiv', cites:2950, pct:72,  url:'https://arxiv.org/abs/2508.04848' },
  { rank:4, id:'2412.16117', title:'Training-free video token pruning for efficient video understanding',      year:'2024', venue:'arXiv', cites:2310, pct:56,  url:'https://arxiv.org/abs/2412.16117' },
  { rank:5, id:'2310.03059', title:'Point-PEFT: Parameter-efficient fine-tuning for 3D point cloud models',   year:'2023', venue:'arXiv', cites:1980, pct:48,  url:'https://arxiv.org/abs/2310.03059' },
  { rank:6, id:'2402.11651', title:'Negative-aware training (NAT) for LLM agent fine-tuning',                 year:'2024', venue:'arXiv', cites:1540, pct:37,  url:'https://arxiv.org/abs/2402.11651' },
  { rank:7, id:'2312.10793', title:'Mixing instruction datasets for LLM fine-tuning: a systematic study',     year:'2023', venue:'arXiv', cites:1260, pct:31,  url:'https://arxiv.org/abs/2312.10793' },
];

const DB_GAPS = [
  { theme:'priv',  color:'#7F77DD', bg:'#EEEDFE', icon_bg:'#ede9fe', label:'Privacy',     voidPct:89, title:'DP noise magnitude grows with model size — no scalable solution exists for large-model private fine-tuning.',                  papers:['2110.06500'] },
  { theme:'perf',  color:'#E24B4A', bg:'#FCEBEB', icon_bg:'#fee2e2', label:'Performance',  voidPct:87, title:'Significant performance decline in advanced reasoning under non-ideal RL inference conditions.',                              papers:['2508.04848'] },
  { theme:'theory',color:'#1D9E75', bg:'#E1F5EE', icon_bg:'#d1fae5', label:'Theory',       voidPct:83, title:'The intrinsically linear nature of fine-tuning large networks on small datasets is not understood.',                          papers:['2403.00946'] },
  { theme:'eff',   color:'#378ADD', bg:'#E6F1FB', icon_bg:'#dbeafe', label:'Efficiency',   voidPct:80, title:'PEFT methods for 3D pre-trained point-cloud models are severely under-explored vs. 2D and text domains.',                    papers:['2310.03059'] },
  { theme:'perf',  color:'#E24B4A', bg:'#FCEBEB', icon_bg:'#fee2e2', label:'Performance',  voidPct:78, title:'Fine-tuning does not necessarily lead to better performance — no reliable predictor identified.',                            papers:['2309.13734','2508.04848'] },
  { theme:'eth',   color:'#BA7517', bg:'#FAEEDA', icon_bg:'#fef3c7', label:'Ethics',        voidPct:62, title:'Ethical implications and biases introduced when LLMs respond with human-like attributes remain unaddressed.',                 papers:['2501.05032'] },
];

function buildTopPapers() {
  const el = document.getElementById('db-top-papers');
  if (!el) return;
  el.innerHTML = DB_TOP_PAPERS.map(function (p) {
    return `<a class="db-paper-card" href="${p.url}" target="_blank" rel="noopener" title="Open on arXiv">
      <div class="db-paper-top">
        <div class="db-paper-rank">${p.rank}</div>
        <div class="db-paper-content">
          <div class="db-paper-title">${p.title}</div>
          <div class="db-paper-meta">
            <span class="db-paper-year">${p.year}</span>
            <span class="db-paper-venue">${p.venue}</span>
            <span class="db-paper-cites">${p.cites.toLocaleString()} citations</span>
            <span class="db-paper-id">${p.id}</span>
            <span class="db-paper-ext">${ext(10)}</span>
          </div>
        </div>
      </div>
      <div class="db-paper-bar"><div class="db-paper-bar-fill" style="width:${p.pct}%;"></div></div>
    </a>`;
  }).join('');
}

function buildGapsList() {
  const el = document.getElementById('db-gaps-list');
  if (!el) return;
  el.innerHTML = DB_GAPS.map(function (g) {
    const chips = g.papers.map(function (p) {
      return `<a class="paper-chip" href="${PM[p]?.u||'https://arxiv.org/abs/'+p}" target="_blank" rel="noopener" onclick="event.stopPropagation();" title="${PM[p]?.t}">${ext(9)} ${p}</a>`;
    }).join('');
    return `<div class="db-gap-card" style="border-left-color:${g.color};">
      <div class="db-gap-head">
        <div class="db-gap-icon" style="background:${g.icon_bg};">
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="${g.color}" stroke-width="1.7" stroke-linecap="round"><circle cx="6" cy="6" r="5"/><path d="M6 4v3"/><circle cx="6" cy="9" r=".5" fill="${g.color}" stroke="none"/></svg>
        </div>
        <span class="db-gap-label" style="color:${g.color};">${g.label}</span>
      </div>
      <div class="db-gap-title">${g.title}</div>
      <div class="db-gap-footer">
        ${chips}
        <div class="db-void-wrap">
          <div class="db-void-bar"><div class="db-void-fill" style="background:${g.color};width:${g.voidPct}%;"></div></div>
          <span class="db-void-lbl">${g.voidPct}% void</span>
        </div>
      </div>
    </div>`;
  }).join('');
}

// ══ 11. DASHBOARD MINI-GRAPH ══════════════════════════════════════════════════
// Visually identical to the full Research Graph panel — same card nodes,
// same curved arc edges, same relationship badge pills, same year-column
// guide lines — just scaled to fit the dashboard card's canvas area.
// Uses the identical GRAPH_RAW data, RG_COLORS palette, and autoFit logic.

function buildDashboardMiniGraph() {
  const canvas = document.getElementById('db-mini-graph-canvas');
  if (!canvas) return;
  // Clear any previous render (e.g. after an SSE batch rebuild)
  canvas.innerHTML = '';

  // Guard: empty state — nothing to draw
  if (!GRAPH_RAW.graph_edges.length) return;

  // ── Container dimensions (read live, never hardcoded) ──────────────────────
  const W = canvas.clientWidth  || 600;
  const H = canvas.clientHeight || 300;

  // ── Node + edge dimensions — proportionally smaller than the full graph ─────
  // Full graph: NODE_W=200, NODE_H=90. Mini uses 50 % scale.
  const NODE_W = 140;
  const NODE_H = 62;

  // ── Parse nodes & links from the same canonical GRAPH_RAW source ───────────
  const nodesMap = new Map();
  const links    = [];

  GRAPH_RAW.graph_edges.forEach(function (e) {
    if (e.source_paper === e.target_paper) return;
    [e.source_paper, e.target_paper].forEach(function (id) {
      if (!nodesMap.has(id)) {
        const p = GRAPH_RAW.papers[id];
        nodesMap.set(id, {
          id:       id,
          concept:  p ? p.core_methodology : 'External citation.',
          year:     p ? p.year             : 'Unknown',
          pagerank: p ? p.pagerank          : 0.3,
        });
      }
    });
    links.push({
      source:  e.source_paper,
      target:  e.target_paper,
      type:    e.relationship_type,
      context: e.relationship_context,
    });
  });

  // Guard: if parsing produced nothing, bail cleanly
  if (!nodesMap.size) return;

  const nodes       = Array.from(nodesMap.values());
  const uniqueYears = Array.from(new Set(nodes.map(function (n) { return n.year; }))).sort();

  // Foundational node — highest PageRank, same logic as full graph
  const foundationalNode = nodes.reduce(function (best, n) {
    return n.pagerank > best.pagerank ? n : best;
  }, nodes[0]);

  // ── SVG root ───────────────────────────────────────────────────────────────
  const svg = d3.select(canvas).append('svg')
    .attr('width',  '100%')
    .attr('height', '100%');

  const defs = svg.append('defs');

  // Dot-grid background — identical pattern to full graph background colour
  const pat = defs.append('pattern')
    .attr('id', 'db-mg-dot-grid').attr('width', 24).attr('height', 24)
    .attr('patternUnits', 'userSpaceOnUse');
  pat.append('circle').attr('cx', 1).attr('cy', 1).attr('r', 1)
    .attr('fill', 'rgba(15,23,60,0.055)');
  svg.append('rect').attr('width', '100%').attr('height', '100%')
    .attr('fill', 'url(#db-mg-dot-grid)');

  const g = svg.append('g');

  // ── Zoom — same scaleExtent as full graph ──────────────────────────────────
  const zoom = d3.zoom()
    .scaleExtent([0.12, 3.5])
    .on('zoom', function (e) { g.attr('transform', e.transform); });
  svg.call(zoom).on('dblclick.zoom', null);

  // ── Arrowhead markers — identical geometry to full graph ───────────────────
  Object.keys(RG_COLORS).forEach(function (type) {
    defs.append('marker')
      .attr('id',          'db-mg-arrow-' + type)
      .attr('viewBox',     '0 -5 10 10')
      .attr('refX',        NODE_W / 2 + 8)
      .attr('refY',        0)
      .attr('markerWidth',  4)
      .attr('markerHeight', 4)
      .attr('orient',      'auto')
      .append('path')
      .attr('fill', RG_COLORS[type].stroke)
      .attr('d',   'M0,-5L10,0L0,5');
  });

  // ── Year-column guide lines — identical to full graph ─────────────────────
  const xScale = d3.scalePoint()
    .domain(uniqueYears)
    .range([NODE_W * 0.7, Math.max(W - NODE_W * 0.7, uniqueYears.length * 220)])
    .padding(0.5);

  const yearLayer = g.append('g').attr('class', 'db-mg-year-layers');
  uniqueYears.forEach(function (year) {
    const xPos = xScale(year);
    // Dashed vertical guide — same stroke style
    yearLayer.append('line')
      .attr('x1', xPos).attr('x2', xPos)
      .attr('y1', -800).attr('y2', 1600)
      .attr('stroke', 'rgba(15,23,60,0.06)')
      .attr('stroke-dasharray', '4,4')
      .attr('stroke-width', 1.5);
    // Year label
    yearLayer.append('text')
      .attr('x', xPos).attr('y', 28)
      .attr('text-anchor', 'middle')
      .attr('font-family', "'DM Mono', monospace")
      .attr('font-size', '11px')
      .attr('font-weight', '600')
      .attr('fill', '#94a3b8')
      .text(year);
  });

  // ── Edges — curved arcs, identical math to full graph ─────────────────────
  const edgeGroup = g.append('g')
    .selectAll('.db-mg-edge-group')
    .data(links)
    .join('g')
    .attr('class', 'db-mg-edge-group');

  const edgePath = edgeGroup.append('path')
    .attr('fill', 'none')
    .attr('stroke', function (d) { return (RG_COLORS[d.type] || RG_COLORS.RELATED).stroke; })
    .attr('stroke-width', 1.2)
    .attr('stroke-opacity', 0.75)
    .attr('marker-end', function (d) {
      return 'url(#db-mg-arrow-' + (RG_COLORS[d.type] ? d.type : 'RELATED') + ')';
    });

  // Relationship badge pills — identical design, scaled font
  const edgeBadge = edgeGroup.append('g').attr('class', 'db-mg-edge-badge');

  edgeBadge.append('rect')
    .attr('width', 60).attr('height', 14)
    .attr('x', -30).attr('y', -7)
    .attr('rx', 7)
    .attr('fill',         function (d) { return (RG_COLORS[d.type] || RG_COLORS.RELATED).bg; })
    .attr('stroke',       function (d) { return (RG_COLORS[d.type] || RG_COLORS.RELATED).stroke; })
    .attr('stroke-width', 0.8);

  edgeBadge.append('text')
    .attr('text-anchor',      'middle')
    .attr('dominant-baseline','central')
    .attr('font-family',      "'DM Sans', sans-serif")
    .attr('font-size',        '7px')
    .attr('font-weight',      '600')
    .attr('pointer-events',   'none')
    .attr('fill', function (d) { return (RG_COLORS[d.type] || RG_COLORS.RELATED).txt; })
    .text(function (d) { return d.type; });

  // ── Nodes — card foreignObject, identical structure to full graph ──────────
  const nodeGroup = g.append('g')
    .selectAll('.db-mg-node')
    .data(nodes)
    .join('g')
    .attr('class', 'db-mg-node')
    .style('cursor', 'pointer')
    .call(d3.drag()
      .on('start', function (event, d) {
        if (!event.active) sim.alphaTarget(0.3).restart();
        d.fx = d.x; d.fy = d.y;
      })
      .on('drag', function (event, d) { d.fx = event.x; d.fy = event.y; })
      .on('end',  function (event, d) {
        if (!event.active) sim.alphaTarget(0);
        d.fx = null; d.fy = null;
      })
    )
    .on('click', function (event, d) {
      window.open('https://arxiv.org/abs/' + d.id.replace('arxiv:', ''), '_blank');
    });

  // Foundational node outer glow ring — identical to full graph dashed rect
  nodeGroup.filter(function (d) { return d === foundationalNode; })
    .append('rect')
    .attr('width',  NODE_W + 6).attr('height', NODE_H + 6)
    .attr('x',     -(NODE_W + 6) / 2).attr('y', -(NODE_H + 6) / 2)
    .attr('rx', 10)
    .attr('fill', 'none')
    .attr('stroke', '#6d28d9')
    .attr('stroke-width', 1.2)
    .attr('stroke-dasharray', '4 3')
    .attr('opacity', 0.5);

  // Card node via foreignObject — same HTML structure, smaller font/padding
  nodeGroup.append('foreignObject')
    .attr('width',  NODE_W)
    .attr('height', NODE_H)
    .attr('x', -NODE_W / 2)
    .attr('y', -NODE_H / 2)
    .append('xhtml:div')
    .attr('class', 'db-mg-node-card')
    .html(function (d) {
      const isF = d === foundationalNode;
      return '<div class="db-mg-node-header">' +
        '<span class="db-mg-node-id">' + d.id.replace('arxiv:', '') + (isF ? ' ★' : '') + '</span>' +
        '<span class="db-mg-node-year">' + d.year + '</span>' +
        '</div>' +
        '<div class="db-mg-node-body">' + d.concept + '</div>';
    });

  // ── Tooltip — identical content, scoped to the canvas ─────────────────────
  const miniTip = d3.select(canvas).append('div')
    .style('position',       'absolute')
    .style('background',     'var(--surface)')
    .style('border',         '1px solid rgba(15,23,60,.13)')
    .style('border-radius',  '10px')
    .style('padding',        '8px 12px')
    .style('font-size',      '10.5px')
    .style('color',          'var(--text2)')
    .style('pointer-events', 'none')
    .style('opacity',        '0')
    .style('transition',     'opacity .15s, transform .15s')
    .style('transform',      'translateY(4px)')
    .style('max-width',      '220px')
    .style('z-index',        '20')
    .style('line-height',    '1.5')
    .style('box-shadow',     '0 8px 20px rgba(0,0,0,0.06)');

  edgeBadge
    .on('mouseover', function (event, d) {
      const theme = RG_COLORS[d.type] || RG_COLORS.RELATED;
      miniTip.html(
        '<div style="font-size:9px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:' + theme.txt + ';margin-bottom:4px;">' + d.type + '</div>' +
        '<div>' + (d.context || '') + '</div>'
      )
      .style('opacity', '1').style('transform', 'translateY(0)')
      .style('left', (event.offsetX + 14) + 'px')
      .style('top',  (event.offsetY + 14) + 'px');
    })
    .on('mousemove', function (event) {
      miniTip.style('left', (event.offsetX + 14) + 'px').style('top', (event.offsetY + 14) + 'px');
    })
    .on('mouseout', function () {
      miniTip.style('opacity', '0').style('transform', 'translateY(4px)');
    });

  nodeGroup
    .on('mouseover', function (event, d) {
      const paper = GRAPH_RAW.papers[d.id];
      miniTip.html(
        '<b style="font-family:\'DM Mono\',monospace;color:#0C447C;font-size:9.5px;">' +
        d.id.replace('arxiv:', '') + '</b>' +
        (d === foundationalNode ? ' <span style="font-size:8px;background:#ede9fe;color:#6d28d9;padding:1px 5px;border-radius:4px;">★ Foundational</span>' : '') +
        '<br><span style="color:var(--text2);">' + (paper ? paper.core_methodology.slice(0, 80) + '…' : '') + '</span>'
      )
      .style('opacity', '1').style('transform', 'translateY(0)')
      .style('left', (event.offsetX + 14) + 'px')
      .style('top',  (event.offsetY + 14) + 'px');
    })
    .on('mousemove', function (event) {
      miniTip.style('left', (event.offsetX + 14) + 'px').style('top', (event.offsetY + 14) + 'px');
    })
    .on('mouseout', function () {
      miniTip.style('opacity', '0').style('transform', 'translateY(4px)');
    });

  // ── Force simulation — same forces, proportionally shorter link distance ───
  const sim = d3.forceSimulation(nodes)
    .force('link',    d3.forceLink(links).id(function (d) { return d.id; }).distance(180))
    .force('charge',  d3.forceManyBody().strength(-900))
    .force('collide', d3.forceCollide().radius(NODE_H * 0.8))
    .force('x',       d3.forceX(function (d) { return xScale(d.year); }).strength(1))
    .force('y',       d3.forceY(H / 2).strength(0.05));

  sim.on('tick', function () {
    // Curved arc paths — same formula as full graph
    edgePath.attr('d', function (d) {
      if (!d.source.x) return '';
      const dx = d.target.x - d.source.x;
      const dy = d.target.y - d.source.y;
      const dr = Math.sqrt(dx * dx + dy * dy) * 1.2;
      return 'M' + d.source.x + ',' + d.source.y +
             'A' + dr + ',' + dr + ' 0 0,1 ' +
             d.target.x + ',' + d.target.y;
    });

    // Badge at arc midpoint — same getTotalLength/getPointAtLength technique
    edgeBadge.attr('transform', function (d) {
      const pathEl = this.parentNode.querySelector('path');
      if (!pathEl) return 'translate(0,0)';
      try {
        const len = pathEl.getTotalLength();
        if (!len) return 'translate(0,0)';
        const mid = pathEl.getPointAtLength(len / 2);
        return 'translate(' + mid.x + ',' + mid.y + ')';
      } catch (e) { return 'translate(0,0)'; }
    });

    nodeGroup.attr('transform', function (d) {
      return 'translate(' + (d.x || 0) + ',' + (d.y || 0) + ')';
    });
  });

  // ── autoFit — 85 % fill, centres on foundational node, same math ──────────
  function autoFit(animate) {
    const bounds = g.node().getBBox();
    // Empty-state guard — no nodes rendered yet
    if (!bounds || !bounds.width || !bounds.height) return;

    const PAD    = 0.85; // fill 85 % of viewport
    let   scale  = Math.min(
      (W * PAD) / bounds.width,
      (H * PAD) / bounds.height
    );
    // Same ceiling/floor as full graph
    scale = Math.min(scale, 1.0);
    scale = Math.max(scale, 0.12);

    const fn = foundationalNode;
    const tx = W / 2 - scale * (fn.x || W / 2);
    const ty = H / 2 - scale * (fn.y || H / 2);

    const transform = d3.zoomIdentity.translate(tx, ty).scale(scale);

    if (animate) {
      svg.transition().duration(700).ease(d3.easeCubicOut)
         .call(zoom.transform, transform);
    } else {
      svg.call(zoom.transform, transform);
    }
  }

  sim.on('end', function () { autoFit(true); });
  // Timed fallback — fires after ~1.8 s regardless of sim state
  setTimeout(function () { autoFit(true); }, 1800);
}

// ══ 12. FULL RESEARCH GRAPH — D3 FORCE LAYOUT ══════════════════════════════════
// Features:
//   • Year-column timeline with dashed guide lines
//   • Curved arc edges with arrowhead markers per relationship type
//   • Relationship badge labels at arc midpoints with hover tooltips
//   • Drag-and-drop nodes
//   • Auto-fit on simulation.end() AND timed fallback — centres on the
//     foundational (highest PageRank) node filling 80 % of the container
//   • Re-fit triggered every time node count increases (batch-triggered reflow)

let rgInitialized = false;
let rgSimulation  = null;
let rgSvg         = null;
let rgZoom        = null;
let rgG           = null;
let rgFoundational = null;
let rgContainerEl  = null;

function initResearchGraph() {
  if (rgInitialized) {
    // Already built — just re-fit on every re-open in case container was resized
    if (rgSvg && rgZoom && rgG) autoFitFullGraph(true);
    return;
  }
  rgInitialized = true;

  const NODE_W = 200;
  const NODE_H = 90;

  // ── Parse nodes & links ───────────────────────────────────────────────────
  const nodesMap = new Map();
  const links    = [];

  function getOrCreateNode(id) {
    if (!nodesMap.has(id)) {
      const paper = GRAPH_RAW.papers[id];
      nodesMap.set(id, {
        id:       id,
        concept:  paper ? paper.core_methodology : 'External citation details unavailable.',
        year:     paper ? paper.year             : 'Unknown',
        pagerank: paper ? paper.pagerank          : 0.3,
      });
    }
    return nodesMap.get(id);
  }

  GRAPH_RAW.graph_edges.forEach(function (edge) {
    if (edge.source_paper === edge.target_paper) return;
    getOrCreateNode(edge.source_paper);
    getOrCreateNode(edge.target_paper);
    links.push({ source: edge.source_paper, target: edge.target_paper, type: edge.relationship_type, context: edge.relationship_context });
  });

  const nodes       = Array.from(nodesMap.values());
  const uniqueYears = Array.from(new Set(nodes.map(function (n) { return n.year; }))).sort();

  // Identify the foundational node (highest PageRank)
  rgFoundational = nodes.reduce(function (best, n) {
    return n.pagerank > best.pagerank ? n : best;
  }, nodes[0]);

  // ── Container ─────────────────────────────────────────────────────────────
  rgContainerEl  = document.getElementById('rg-graph-container');
  const width    = rgContainerEl.clientWidth  || 1000;
  const height   = rgContainerEl.clientHeight || 600;

  // ── SVG root ──────────────────────────────────────────────────────────────
  rgSvg = d3.select('#rg-graph-container').append('svg')
    .attr('width',  '100%')
    .attr('height', '100%');

  rgZoom = d3.zoom()
    .scaleExtent([0.12, 3.5])
    .on('zoom', function (e) { rgG.attr('transform', e.transform); });

  rgSvg.call(rgZoom)
       .on('click', function () { rgTooltip.classed('rg-visible', false); });

  rgG = rgSvg.append('g');

  // ── Defs: arrowhead markers ───────────────────────────────────────────────
  const defs = rgSvg.append('defs');
  Object.keys(RG_COLORS).forEach(function (type) {
    defs.append('marker')
      .attr('id',          'rg-arrow-' + type)
      .attr('viewBox',     '0 -5 10 10')
      .attr('refX',        NODE_W / 2 + 10)
      .attr('refY',        0)
      .attr('markerWidth',  5)
      .attr('markerHeight', 5)
      .attr('orient',      'auto')
      .append('path')
      .attr('fill', RG_COLORS[type].stroke)
      .attr('d',   'M0,-5L10,0L0,5');
  });

  // ── Year guide lines ──────────────────────────────────────────────────────
  const xScale = d3.scalePoint()
    .domain(uniqueYears)
    .range([220, Math.max(width - 220, uniqueYears.length * 350)])
    .padding(0.5);

  const yearLayer = rgG.append('g').attr('class', 'rg-year-layers');
  uniqueYears.forEach(function (year) {
    const xPos = xScale(year);
    yearLayer.append('line')
      .attr('x1', xPos).attr('x2', xPos).attr('y1', -1000).attr('y2', 2000)
      .attr('stroke', 'rgba(15,23,60,0.06)').attr('stroke-dasharray', '4,4').attr('stroke-width', 2);
    yearLayer.append('text')
      .attr('x', xPos).attr('y', 50).attr('text-anchor', 'middle')
      .attr('font-family', "'DM Mono', monospace").attr('font-size', '17px')
      .attr('font-weight', '600').attr('fill', '#94a3b8').text(year);
  });

  // ── Edges ─────────────────────────────────────────────────────────────────
  const edgeGroup = rgG.append('g')
    .selectAll('.rg-edge-group').data(links).join('g').attr('class', 'rg-edge-group');

  const edgePath = edgeGroup.append('path')
    .attr('class', 'rg-edge-path')
    .attr('stroke', function (d) { return (RG_COLORS[d.type] || RG_COLORS.RELATED).stroke; })
    .attr('marker-end', function (d) { return 'url(#rg-arrow-' + (RG_COLORS[d.type] ? d.type : 'RELATED') + ')'; });

  const edgeBadge = edgeGroup.append('g').attr('class', 'rg-edge-badge');
  edgeBadge.append('rect')
    .attr('class', 'rg-edge-badge-rect')
    .attr('width', 80).attr('height', 20).attr('x', -40).attr('y', -10)
    .attr('fill',   function (d) { return (RG_COLORS[d.type] || RG_COLORS.RELATED).bg; })
    .attr('stroke', function (d) { return (RG_COLORS[d.type] || RG_COLORS.RELATED).stroke; })
    .attr('stroke-width', 1).attr('rx', 10);
  edgeBadge.append('text')
    .attr('class', 'rg-edge-badge-text')
    .attr('fill', function (d) { return (RG_COLORS[d.type] || RG_COLORS.RELATED).txt; })
    .text(function (d) { return d.type; });

  // ── Nodes ─────────────────────────────────────────────────────────────────
  const nodeGroup = rgG.append('g')
    .selectAll('.rg-node').data(nodes).join('g').attr('class', 'rg-node')
    .call(d3.drag().on('start', dragStarted).on('drag', dragged).on('end', dragEnded));

  // Foundational node glow ring
  nodeGroup.filter(function (d) { return d === rgFoundational; })
    .append('rect')
    .attr('width', NODE_W + 8).attr('height', NODE_H + 8)
    .attr('x', -(NODE_W + 8) / 2).attr('y', -(NODE_H + 8) / 2)
    .attr('rx', 15)
    .attr('fill', 'none')
    .attr('stroke', '#6d28d9')
    .attr('stroke-width', 1.5)
    .attr('stroke-dasharray', '4 3')
    .attr('opacity', 0.5);

  nodeGroup.append('foreignObject')
    .attr('width', NODE_W).attr('height', NODE_H)
    .attr('x', -NODE_W / 2).attr('y', -NODE_H / 2)
    .append('xhtml:div').attr('class', 'rg-node-card')
    .html(function (d) {
      const isF = d === rgFoundational;
      return '<div class="rg-node-header">' +
        '<span class="rg-node-id">' + d.id.replace('arxiv:', '') + (isF ? ' ★' : '') + '</span>' +
        '<span class="rg-node-year">' + d.year + '</span>' +
        '</div>' +
        '<div class="rg-node-body" title="' + d.concept + '">' + d.concept + '</div>';
    });

  // ── Tooltip ───────────────────────────────────────────────────────────────
  const rgTooltip = d3.select('#rg-tooltip');

  edgeBadge
    .on('mouseover', function (event, d) {
      const theme = RG_COLORS[d.type] || RG_COLORS.RELATED;
      rgTooltip.html(
        '<div class="rg-tt-title" style="color:' + theme.txt + '">' + d.type + '</div>' +
        '<div class="rg-tt-body">' + d.context + '</div>'
      );
      const rect = rgContainerEl.getBoundingClientRect();
      rgTooltip
        .style('left', (event.clientX - rect.left + 15) + 'px')
        .style('top',  (event.clientY - rect.top  + 15) + 'px');
      rgTooltip.classed('rg-visible', true);
    })
    .on('mouseout', function () { rgTooltip.classed('rg-visible', false); });

  // ── Force simulation ──────────────────────────────────────────────────────
  rgSimulation = d3.forceSimulation(nodes)
    .force('link',    d3.forceLink(links).id(function (d) { return d.id; }).distance(260))
    .force('charge',  d3.forceManyBody().strength(-1600))
    .force('collide', d3.forceCollide().radius(NODE_H))
    .force('x',       d3.forceX(function (d) { return xScale(d.year); }).strength(1))
    .force('y',       d3.forceY(height / 2).strength(0.05));

  rgSimulation.on('tick', function () {
    edgePath.attr('d', function (d) {
      const dx = d.target.x - d.source.x;
      const dy = d.target.y - d.source.y;
      const dr = Math.sqrt(dx * dx + dy * dy) * 1.2;
      return 'M' + d.source.x + ',' + d.source.y + 'A' + dr + ',' + dr + ' 0 0,1 ' + d.target.x + ',' + d.target.y;
    });

    edgeBadge.attr('transform', function (d) {
      const pathNode = this.parentNode.querySelector('.rg-edge-path');
      if (!pathNode) return 'translate(0,0)';
      const len = pathNode.getTotalLength();
      const mid = pathNode.getPointAtLength(len / 2);
      return 'translate(' + mid.x + ',' + mid.y + ')';
    });

    nodeGroup.attr('transform', function (d) { return 'translate(' + d.x + ',' + d.y + ')'; });
  });

  // ── Auto-fit with foundational-node centering ──────────────────────────────
  rgSimulation.on('end', function () { autoFitFullGraph(true); });
  setTimeout(function () { autoFitFullGraph(true); }, 2000);

  // ── Drag handlers ─────────────────────────────────────────────────────────
  function dragStarted(event, d) {
    if (!event.active) rgSimulation.alphaTarget(0.3).restart();
    d.fx = d.x; d.fy = d.y;
  }
  function dragged(event, d) { d.fx = event.x; d.fy = event.y; }
  function dragEnded(event, d) {
    if (!event.active) rgSimulation.alphaTarget(0);
    d.fx = null; d.fy = null;
  }
}

// ── Shared auto-fit for the full graph ────────────────────────────────────────
// Calculates exact bounding box of all currently rendered nodes,
// scales so the graph fills 80 % of the container, and centres the
// viewport on the foundational (highest PageRank) node.
// Even if a new node appears at the far edge of coordinate space,
// the BBox recalculation pulls it into the visible frame.

function autoFitFullGraph(animate) {
  if (!rgSvg || !rgG || !rgZoom || !rgFoundational || !rgContainerEl) return;

  const W      = rgContainerEl.clientWidth  || 1000;
  const H      = rgContainerEl.clientHeight || 600;
  const bounds = rgG.node().getBBox();
  if (!bounds.width || !bounds.height) return;

  // Fill 80 % of the viewport
  const TARGET = 0.80;
  let scale = Math.min(
    (W * TARGET) / bounds.width,
    (H * TARGET) / bounds.height
  );
  // Hard ceiling — never zoom in past 1.0 (avoids pixelated foreignObject text)
  scale = Math.min(scale, 1.0);
  // Hard floor — never zoom out so far that nodes become illegible
  scale = Math.max(scale, 0.12);

  // Centre the foundational node in the viewport
  const fn = rgFoundational;
  const tx = W / 2 - scale * fn.x;
  const ty = H / 2 - scale * fn.y;

  const transform = d3.zoomIdentity.translate(tx, ty).scale(scale);

  if (animate) {
    rgSvg.transition().duration(750).ease(d3.easeCubicOut)
         .call(rgZoom.transform, transform);
  } else {
    rgSvg.call(rgZoom.transform, transform);
  }
}

// ── Re-fit whenever node count increases (batch-triggered reflow) ──────────────
AppState.subscribe(function (state) {
  if (rgInitialized && rgSimulation) {
    // Reheat simulation briefly on a new batch so layout adjusts
    if (state.syncing === false && state.papers > 10) {
      rgSimulation.alphaTarget(0.2).restart();
      setTimeout(function () {
        rgSimulation.alphaTarget(0);
        autoFitFullGraph(true);
      }, 1200);
    }
  }
});

// ══ 13. ENTRY POINT ════════════════════════════════════════════════════════════

window.addEventListener('DOMContentLoaded', function () {
  switchPanel('dashboard');
});

// ═══════════════════════════════════════════════════════════════════════════════
// ══ 14. CITATION TRAIL EXPLORER — complete Vanilla JS + D3 implementation ══════
// ─── Ported from the supplied React component. No React dependency. ────────────
// ─── Uses existing AppState, PAGE_META hook, and RG_COLORS from §3. ───────────
// ═══════════════════════════════════════════════════════════════════════════════

(function CitationTrailModule() {
  'use strict';

  // ── 14.1  DATA  ─────────────────────────────────────────────────────────────
  // Mirrors React component's NODE_DATA exactly (10 papers, 35-node cap enforced)

  var CT_CAP = 35;

  var CT_NODES = [
    { id:0, arxiv:'arxiv:2106.09685', year:'2021', shortName:'LoRA',         initials:'L',  col:0,
      method:'Introduces trainable low-rank decomposition matrices injected into transformer layers, drastically reducing the number of trainable parameters for LLM fine-tuning.',
      datasets:['GLUE','SuperGLUE','E2E NLG'], metrics:['BLEU','ROUGE','Accuracy'],
      weaknesses:'Fixed rank for all layers; no dynamic budget allocation across weight matrices.',
      gaps:'Automated rank selection; multi-task LoRA sharing strategies.',
      url:'https://arxiv.org/abs/2106.09685' },
    { id:1, arxiv:'arxiv:2104.08691', year:'2021', shortName:'Prompt Tuning', initials:'P',  col:0,
      method:'Prepends a small set of learnable soft-prompt tokens to the input sequence. Only the prompt embeddings are updated; the LLM backbone is frozen.',
      datasets:['SuperGLUE','T5 benchmarks'], metrics:['Accuracy','F1'],
      weaknesses:'Requires very large model scale (11B+) to match full fine-tuning quality.',
      gaps:'Effective soft prompts for smaller models; prompt initialization strategies.',
      url:'https://arxiv.org/abs/2104.08691' },
    { id:2, arxiv:'arxiv:2210.11610', year:'2022', shortName:'AdaLoRA',       initials:'A',  col:1,
      method:'Extends LoRA with adaptive rank allocation: uses SVD decomposition to estimate the importance of each weight matrix and dynamically redistributes the rank budget.',
      datasets:['GLUE','SQuAD','XSum'], metrics:['Accuracy','F1','ROUGE-L'],
      weaknesses:'SVD-based importance scoring adds training overhead; rank pruning can be unstable early in training.',
      gaps:'Cheaper importance proxies; dynamic rank during inference.',
      url:'https://arxiv.org/abs/2210.11610' },
    { id:3, arxiv:'arxiv:2205.05638', year:'2022', shortName:'Prefix-Tuning', initials:'P',  col:1,
      method:'Prepends trainable continuous vectors to keys and values of every transformer attention layer. Unlike prompt tuning, these prefixes propagate through all layers, not just the input.',
      datasets:['E2E NLG','WebNLG','DART'], metrics:['BLEU','MeteorScore','TER'],
      weaknesses:'Training instability for longer prefix sequences; harder to optimize than LoRA-style adapters.',
      gaps:'Prefix length automation; combining prefix-tuning with quantization.',
      url:'https://arxiv.org/abs/2205.05638' },
    { id:4, arxiv:'arxiv:2303.15647', year:'2023', shortName:'QLoRA',         initials:'Q',  col:2,
      method:'Combines 4-bit NormalFloat quantization of the frozen base model with LoRA adapters in full precision. Enables fine-tuning of 65B-parameter models on a single 48GB GPU.',
      datasets:['Vicuna benchmark','MMLU','HumanEval'], metrics:['MMLU accuracy','Win-rate vs ChatGPT','Pass@1'],
      weaknesses:'Quantization noise accumulates at very low bit-widths; slower forward passes.',
      gaps:'Sub-4-bit stable training; QLoRA for vision-language models.',
      url:'https://arxiv.org/abs/2303.15647' },
    { id:5, arxiv:'arxiv:2309.14322', year:'2023', shortName:'LongLoRA',      initials:'LL', col:2,
      method:'Extends LoRA to long-context fine-tuning using Shifted Sparse Attention (S²-Attn), which approximates full attention at a fraction of the compute cost.',
      datasets:['PG19','Proof-pile','arXiv papers'], metrics:['Perplexity','SCROLLS score'],
      weaknesses:'Attention approximation trades off recall on very long documents; not fully lossless.',
      gaps:'Efficient long-context RLHF; combining LongLoRA with retrieval augmentation.',
      url:'https://arxiv.org/abs/2309.14322' },
    { id:6, arxiv:'arxiv:2301.12503', year:'2023', shortName:'PEFT Survey',   initials:'S',  col:2,
      method:'Comprehensive survey of parameter-efficient fine-tuning methods: adapter layers, prefix-tuning, prompt tuning, LoRA variants. Provides unified taxonomy and empirical comparison.',
      datasets:['Varied (consolidated benchmarks)'], metrics:['Relative accuracy vs full FT','Parameter efficiency ratio'],
      weaknesses:'Survey breadth vs depth trade-off; some results cherry-picked from original papers.',
      gaps:'Unified PEFT benchmark suite; standardized evaluation protocol.',
      url:'https://arxiv.org/abs/2301.12503' },
    { id:7, arxiv:'arxiv:2402.11651', year:'2024', shortName:'DoRA',          initials:'D',  col:3,
      method:'Decomposes pretrained weights into magnitude and direction components. Only the direction is updated via LoRA; magnitude is a scalar. Shown to more closely mimic full fine-tuning dynamics.',
      datasets:['Commonsense reasoning','FLAN','MT-Bench'], metrics:['Commonsense accuracy','MT-Bench score','FLAN accuracy'],
      weaknesses:'Decomposition adds inference overhead; magnitude scalar can destabilize training on some tasks.',
      gaps:'Hardware-aware decomposition; DoRA for mixture-of-experts models.',
      url:'https://arxiv.org/abs/2402.11651' },
    { id:8, arxiv:'arxiv:2508.04848', year:'2025', shortName:'LoRA-XTEND',   initials:'LX', col:3,
      method:'Cross-domain LoRA weight transfer: learns a rank-adaptive alignment matrix to transfer LoRA adapters trained on one domain to a target domain without full re-training.',
      datasets:['CrossFit','MTEB','BigBench'], metrics:['Cross-domain accuracy','MTEB score','Transfer efficiency'],
      weaknesses:'Cross-domain gap can cause instability; alignment matrix adds parameters.',
      gaps:'Domain-adaptive rank selection; transfer for multilingual models.',
      url:'https://arxiv.org/abs/2508.04848' },
    { id:9, arxiv:'arxiv:2602.08239', year:'2026', shortName:'NTK-LoRA',     initials:'NK', col:3,
      method:'Theoretical analysis of LoRA through the Neural Tangent Kernel (NTK) framework. Derives convergence bounds and shows that rank choice controls the inductive bias of the adapter.',
      datasets:['LoRA on LLMs (replication)','NTK spectrum analysis'], metrics:['NTK alignment score','Convergence rate','Generalization bound'],
      weaknesses:'Theoretical bounds are loose in practice; NTK regime assumptions may not hold for large models.',
      gaps:'Empirical NTK-guided rank initialization; NTK analysis for quantized adapters.',
      url:'https://arxiv.org/abs/2602.08239' },
  ];

  // Enforce 35-node cap
  CT_NODES = CT_NODES.slice(0, CT_CAP);

  // [from_id, to_id, type, reason]  — strict mirror of React component EDGES
  var CT_EDGES = [
    [0,2,'EXTENDS',    'AdaLoRA builds directly on LoRA\'s low-rank parameterization and adds SVD-based adaptive rank allocation on top of the same adapter injection strategy.'],
    [0,4,'EXTENDS',    'QLoRA adopts LoRA adapters unchanged but wraps them around a 4-bit quantized backbone, extending the method to extreme memory-efficiency settings.'],
    [0,5,'EXTENDS',    'LongLoRA retains LoRA\'s adapter structure and combines it with shifted sparse attention to extend the approach to long-context fine-tuning.'],
    [0,7,'EXTENDS',    'DoRA decomposes the same weight matrices targeted by LoRA into magnitude and direction, reusing the low-rank update concept with a finer-grained decomposition.'],
    [2,7,'OUTPERFORMS','DoRA outperforms AdaLoRA on commonsense reasoning and MT-Bench, as the magnitude-direction decomposition better captures full fine-tuning dynamics than SVD rank pruning alone.'],
    [7,8,'EXTENDS',    'LoRA-XTEND builds on DoRA\'s weight decomposition idea and adds a cross-domain alignment matrix to enable adapter transfer between domains without full re-training.'],
    [4,9,'EXTENDS',    'NTK-LoRA uses QLoRA\'s replication suite as one of its empirical validation sets and frames QLoRA\'s quantization noise as a perturbation to the NTK spectrum.'],
    [1,3,'RELATED',    'Both Prompt Tuning and Prefix-Tuning are prompt-based PEFT methods that freeze the backbone. Prefix-Tuning generalizes Prompt Tuning by prepending to all attention layers rather than just the input.'],
    [1,0,'RELATED',    'Prompt Tuning and LoRA are contemporaneous PEFT approaches; the PEFT literature treats them as complementary: one modifies inputs, the other modifies weights.'],
    [3,0,'RELATED',    'Prefix-Tuning and LoRA are compared directly in multiple surveys; they represent different schools of PEFT (prompt-space vs weight-space adaptation).'],
    [6,0,'RELATED',    'The PEFT Survey uses LoRA as its primary weight-space baseline and dedicates the largest analysis section to LoRA variants.'],
    [6,3,'RELATED',    'The PEFT Survey covers Prefix-Tuning as one of three foundational prompt-based methods and benchmarks it against LoRA across tasks.'],
    [2,3,'CONTRADICTS','AdaLoRA claims that fixed-rank LoRA (which Prefix-Tuning\'s authors also used as a baseline) under-allocates rank to critical layers. The adaptive budget produces better results at the same parameter count, directly contradicting Prefix-Tuning\'s implicit claim that a uniform soft-prompt budget suffices.'],
    [9,3,'CONTRADICTS','NTK-LoRA\'s theoretical analysis shows that the inductive bias introduced by low-rank adapters is fundamentally different from the continuous-prompt bias of Prefix-Tuning, contradicting the assumption in Prefix-Tuning that prompt-space and weight-space PEFT methods are interchangeable for the same tasks.'],
  ];

  // Column metadata — mirrors React COLUMNS
  var CT_COLUMNS = [
    { label:'Foundational', era:'2021',  colBg:'#EEF2FF', colTxt:'#4F46E5' },
    { label:'Adaptations',  era:'2022',  colBg:'#F0FDF4', colTxt:'#16A34A' },
    { label:'Extensions',   era:'2023',  colBg:'#FDF4FF', colTxt:'#9333EA' },
    { label:'Frontier',     era:'2024+', colBg:'#1E1B4B', colTxt:'#C4B5FD' },
  ];

  // Edge visual style — mirrors React EDGE_STYLE / EDGE_BADGE
  var CT_ES = {
    EXTENDS:     { color:'#4F46E5', dash:null,  width:2,   bg:'#EEF2FF', txt:'#4338CA' },
    CONTRADICTS: { color:'#DC2626', dash:'6,3', width:1.5, bg:'#FEF2F2', txt:'#991B1B' },
    OUTPERFORMS: { color:'#16A34A', dash:null,  width:2.5, bg:'#F0FDF4', txt:'#166534' },
    RELATED:     { color:'#9CA3AF', dash:'3,3', width:1,   bg:'#F9FAFB', txt:'#374151' },
  };

  // ── 14.2  LAYOUT CONSTANTS  ──────────────────────────────────────────────────
  // Column card layout — pixel-perfect match with React component
  var COL_W     = 218;   // column card width
  var COL_GAP   = 50;    // horizontal gap between column cards
  var COL_TOP   = 40;    // top offset of column cards
  var NODE_H    = 46;    // height of each node row (excl. margin)
  var NODE_MB   = 5;     // margin-bottom between node rows
  var COL_HDR_H = 44;    // column header height
  var COL_PB    = 7;     // padding-bottom inside column card
  var COL_HZ    = 7;     // horizontal padding inside column card

  // Canvas virtual size (grows with data)
  function ctVirtualSize(visNodes) {
    var cols = CT_COLUMNS.length;
    var maxRows = 0;
    for (var ci = 0; ci < CT_COLUMNS.length; ci++) {
      var cnt = visNodes.filter(function(n){ return n.col === ci; }).length;
      if (cnt > maxRows) maxRows = cnt;
    }
    return {
      w: cols * (COL_W + COL_GAP) - COL_GAP + 56,
      h: COL_TOP + COL_HDR_H + maxRows * (NODE_H + NODE_MB) + COL_PB + 60,
    };
  }

  // ── 14.3  MODULE STATE  ──────────────────────────────────────────────────────
  var ctReady      = false;   // true after first initCitationTrail()
  var ctSVG        = null;    // D3 selection of #ct-svg
  var ctZoom       = null;    // d3.zoom behaviour
  var ctG          = null;    // main <g> group (transformed by zoom)
  var ctEdgeLayer  = null;    // <g> for edges (behind nodes)
  var ctNodeLayer  = null;    // <g> for column foreignObjects
  var ctActiveId   = null;    // currently selected node id (or null)
  var ctHoveredId  = null;    // hovered node id (for trail preview)
  var ctFilterCol  = 'all';   // active era-filter ('all' | 0|1|2|3)
  var ctPorts      = {};      // nodeId → { rx:{x,y}, lx:{x,y} }  (right/left ports)
  var ctVisNodes   = [];      // current visible nodes after filter
  var ctVisEdges   = [];      // current visible edges after filter
  var ctIsPanning  = false;
  var ctPanStart   = null;

  // ── 14.4  PUBLIC API (called from HTML onclick / switchPanel) ─────────────────

  // Exposed globally so HTML onclick handlers can reach them
  window.ctAutoFit   = ctAutoFit;
  window.ctCloseDetail = ctCloseDetail;

  // ctFilterCol is also called from HTML onclick — expose it
  window.ctFilterCol = function(btnEl, colVal) {
    ctFilterCol = (colVal === 'all') ? 'all' : parseInt(colVal, 10);
    // Update chip active states
    document.querySelectorAll('#ct-col-filters .ct-chip').forEach(function(b){
      b.classList.remove('ct-chip-active', 'ct-chip-col-active');
    });
    if (colVal === 'all') {
      btnEl.classList.add('ct-chip-active');
    } else {
      btnEl.classList.add('ct-chip-col-active');
      btnEl.style.background = btnEl.style.getPropertyValue('--cc-bg') || '#EEF2FF';
      btnEl.style.color = btnEl.style.getPropertyValue('--cc-txt') || '#4F46E5';
    }
    _rebuild();
  };

  // ── 14.5  INITIALISER  ───────────────────────────────────────────────────────
  function initCitationTrail() {
    if (ctReady) {
      ctAutoFit(true);
      return;
    }
    ctReady = true;

    var wrap = document.getElementById('ct-canvas-wrap');
    var svgEl = document.getElementById('ct-svg');
    if (!wrap || !svgEl) return;

    // Ensure defs exist
    ctSVG = d3.select(svgEl);
    if (ctSVG.select('defs').empty()) ctSVG.append('defs');

    // Build arrowhead markers for each edge type
    var defs = ctSVG.select('defs');
    Object.keys(CT_ES).forEach(function(type) {
      var s = CT_ES[type];
      defs.append('marker')
        .attr('id',          'ct-ah-' + type)
        .attr('viewBox',     '0 0 10 10')
        .attr('refX',        8).attr('refY', 5)
        .attr('markerWidth', 5).attr('markerHeight', 5)
        .attr('orient',      'auto')
        .append('path')
        .attr('d',          'M2 1L8 5L2 9')
        .attr('fill',        'none')
        .attr('stroke',      s.color)
        .attr('stroke-width','1.5')
        .attr('stroke-linecap','round');
    });

    // Zoom behaviour
    ctZoom = d3.zoom()
      .scaleExtent([0.15, 3])
      .on('zoom', function(e) {
        if (ctG) ctG.attr('transform', e.transform);
        _updateZoomPct(e.transform.k);
      });

    ctSVG.call(ctZoom)
      .on('dblclick.zoom', null)
      // Click on bare canvas deselects
      .on('click', function(e) {
        if (e.target === svgEl) ctCloseDetail();
      });

    // Layer groups
    ctG         = ctSVG.append('g').attr('class','ct-main-g');
    ctEdgeLayer = ctG.append('g').attr('class','ct-edges');
    ctNodeLayer = ctG.append('g').attr('class','ct-nodes');

    // Build zoom controls
    _buildZoomControls(wrap);

    // Legend bar
    _buildLegendBar(wrap);

    // Pan support on the wrapper div
    wrap.addEventListener('mousedown', _onPanStart);
    window.addEventListener('mousemove', _onPanMove);
    window.addEventListener('mouseup',   _onPanEnd);

    // Wheel zoom (non-passive so we can preventDefault)
    wrap.addEventListener('wheel', function(e) {
      e.preventDefault();
      var step = e.deltaY < 0 ? 0.12 : -0.12;
      var t = d3.zoomTransform(svgEl);
      var newK = Math.min(3, Math.max(0.15, t.k + step));
      // Zoom toward cursor
      var rect = wrap.getBoundingClientRect();
      var cx = e.clientX - rect.left;
      var cy = e.clientY - rect.top;
      var newT = d3.zoomIdentity
        .translate(cx, cy)
        .scale(newK / t.k)
        .translate(-cx, -cy)
        .translate(t.x, t.y)
        .scale(t.k);
      // Simpler: just scale uniformly
      ctSVG.transition().duration(80)
        .call(ctZoom.scaleTo, newK);
    }, { passive: false });

    // Subscribe to AppState SSE so sync indicator updates
    AppState.subscribe(function(state) {
      var ind = document.getElementById('ct-sync-indicator');
      var lbl = document.getElementById('ct-sync-label');
      if (!ind || !lbl) return;
      if (state.syncing) {
        ind.className = 'ct-sync-active';
        lbl.textContent = 'Syncing\u2026';
      } else {
        ind.className = 'ct-sync-idle';
        lbl.textContent = 'Live \u00b7 ' + CT_NODES.length + ' nodes';
        // Smooth re-fit after each batch
        setTimeout(function(){ ctAutoFit(true); }, 600);
      }
    });

    // First render
    _rebuild();
  }

  // ── 14.6  REBUILD — re-draw everything when filter or selection changes ───────
  function _rebuild() {
    if (!ctG) return;

    // Apply era filter
    ctVisNodes = CT_NODES.filter(function(n) {
      return ctFilterCol === 'all' || n.col === ctFilterCol;
    });

    // Filter edges: both endpoints must be visible
    var visIds = new Set(ctVisNodes.map(function(n){ return n.id; }));
    ctVisEdges = CT_EDGES.filter(function(e){
      return visIds.has(e[0]) && visIds.has(e[1]);
    });

    ctPorts = {};

    // Clear layers
    ctEdgeLayer.selectAll('*').remove();
    ctNodeLayer.selectAll('*').remove();

    if (!ctVisNodes.length) return;

    var dims = ctVirtualSize(ctVisNodes);

    // ── Draw column cards via foreignObject ────────────────────────────────
    CT_COLUMNS.forEach(function(col, ci) {
      var colNodes = ctVisNodes.filter(function(n){ return n.col === ci; });
      if (!colNodes.length) return;

      var colX = 28 + ci * (COL_W + COL_GAP);
      var colH = COL_HDR_H + colNodes.length * (NODE_H + NODE_MB) + COL_PB;

      var fo = ctNodeLayer.append('foreignObject')
        .attr('x',       colX)
        .attr('y',       COL_TOP)
        .attr('width',   COL_W)
        .attr('height',  colH + 2);

      var root = fo.append('xhtml:div')
        .attr('class','ct-col-card')
        .style('border-top', '2.5px solid ' + col.colTxt);

      // Header
      var hdr = root.append('xhtml:div').attr('class','ct-col-header');
      hdr.append('xhtml:div').attr('class','ct-col-badge')
        .style('background', col.colBg)
        .style('color',      col.colTxt)
        .text(col.label[0]);
      hdr.append('xhtml:div').attr('class','ct-col-label')
        .style('color', col.colTxt)
        .text(col.label + ' \u00b7 ' + col.era);

      // Node rows
      colNodes.forEach(function(node) {
        var edgeCt = CT_EDGES.filter(function(e){
          return e[0] === node.id || e[1] === node.id;
        }).length;

        var isSelected   = ctActiveId === node.id;
        var isHighlighted = false;
        var isDimmed      = false;
        if (ctActiveId !== null) {
          var connected = CT_EDGES.some(function(e){
            return (e[0] === ctActiveId || e[1] === ctActiveId) &&
                   (e[0] === node.id   || e[1] === node.id);
          });
          if (node.id === ctActiveId) isSelected = true;
          else if (connected) isHighlighted = true;
          else isDimmed = true;
        } else if (ctHoveredId !== null) {
          var connH = CT_EDGES.some(function(e){
            return (e[0] === ctHoveredId || e[1] === ctHoveredId) &&
                   (e[0] === node.id    || e[1] === node.id);
          });
          if (!connH && node.id !== ctHoveredId) isDimmed = true;
        }

        var row = root.append('xhtml:div')
          .attr('class', 'ct-node-row' +
            (isSelected    ? ' ct-node-selected' : '') +
            (isDimmed      ? ' ct-node-dimmed'   : ''))
          .attr('data-nid', node.id);

        if (isHighlighted && !isSelected) {
          row.style('border-color','#7C3AED')
             .style('box-shadow','0 0 0 2px #F3F0FF');
        }

        // Avatar
        row.append('xhtml:div').attr('class','ct-node-avatar')
          .style('background', col.colBg)
          .style('color',      col.colTxt)
          .text(node.initials);

        // Name + meta
        var txt = row.append('xhtml:div').attr('class','ct-node-text');
        txt.append('xhtml:div').attr('class','ct-node-name').text(node.shortName);
        txt.append('xhtml:div').attr('class','ct-node-meta')
          .text(node.year + ' \u00b7 ' + node.arxiv.slice(0, 14));

        // Edge count badge
        row.append('xhtml:div').attr('class','ct-node-count')
          .style('color', col.colTxt)
          .html('<svg width="6" height="6" viewBox="0 0 6 6"><circle cx="3" cy="3" r="3" fill="' + col.colTxt + '"/></svg>\u00a0' + edgeCt);

        // Events
        row.on('click', function(event) {
          event.stopPropagation();
          if (ctActiveId === node.id) {
            ctCloseDetail();
          } else {
            ctActiveId = node.id;
            _openDetail(node);
            _rebuild();
          }
        });
        row.on('mouseenter', function() {
          ctHoveredId = node.id;
          _rebuild();
        });
        row.on('mouseleave', function() {
          ctHoveredId = null;
          _rebuild();
        });
      });
    });

    // ── Measure ports after layout settles ────────────────────────────────
    requestAnimationFrame(function() {
      _measurePorts();
      _drawEdges();
      requestAnimationFrame(function() {
        _measurePorts();
        _drawEdges();
        ctAutoFit(false);
      });
    });
  }

  // ── 14.7  PORT MEASUREMENT  ──────────────────────────────────────────────────
  // Reads each node-row's screen rect and converts to SVG user-space coords.
  function _measurePorts() {
    var svgEl = document.getElementById('ct-svg');
    if (!svgEl) return;
    var svgRect = svgEl.getBoundingClientRect();
    var t = d3.zoomTransform(svgEl);

    ctVisNodes.forEach(function(node) {
      var rows = document.querySelectorAll('.ct-node-row[data-nid="' + node.id + '"]');
      if (!rows.length) return;
      var r = rows[0].getBoundingClientRect();
      if (!r.width) return;

      // Screen → SVG user space (undo zoom + pan)
      var x = (r.left  - svgRect.left - t.x) / t.k;
      var y = (r.top   - svgRect.top  - t.y) / t.k;
      var w = r.width  / t.k;
      var h = r.height / t.k;

      ctPorts[node.id] = {
        rx: { x: x + w, y: y + h / 2 },
        lx: { x: x,     y: y + h / 2 },
      };
    });
  }

  // ── 14.8  EDGE DRAWING  ──────────────────────────────────────────────────────
  // Cubic-bezier paths with arrowheads + badge pills at midpoint.
  // Opacity controlled by active/hover state — mirrors React component logic.
  function _drawEdges() {
    ctEdgeLayer.selectAll('*').remove();

    ctVisEdges.forEach(function(e) {
      var from = e[0], to = e[1], type = e[2], reason = e[3];
      var p1 = ctPorts[from];
      var p2 = ctPorts[to];
      if (!p1 || !p2) return;

      var s    = CT_ES[type] || CT_ES.RELATED;
      var mx   = (p1.rx.x + p2.lx.x) / 2;
      var path = 'M' + p1.rx.x + ',' + p1.rx.y
               + ' C' + mx + ',' + p1.rx.y
               + ' ' + mx  + ',' + p2.lx.y
               + ' ' + p2.lx.x + ',' + p2.lx.y;

      // Opacity: default faded; active edge = full; dimmed = near-invisible
      var activeNode = ctActiveId !== null ? ctActiveId : ctHoveredId;
      var opacity = 0.45;
      if (activeNode !== null) {
        opacity = (e[0] === activeNode || e[1] === activeNode) ? 1 : 0.04;
      }

      var eg = ctEdgeLayer.append('g').attr('class','ct-edge-group');

      // Cubic bezier
      eg.append('path')
        .attr('d',           path)
        .attr('fill',        'none')
        .attr('stroke',      s.color)
        .attr('stroke-width', s.width)
        .attr('stroke-dasharray', s.dash || null)
        .attr('opacity',     opacity)
        .attr('marker-end',  'url(#ct-ah-' + type + ')')
        .style('transition', 'opacity .18s');

      // Badge pill at bezier midpoint
      var mx2 = (p1.rx.x + p2.lx.x) / 2;
      var my  = (p1.rx.y + p2.lx.y) / 2;
      var bW  = 66, bH = 15;

      var bg = eg.append('g')
        .attr('transform', 'translate(' + mx2 + ',' + my + ')')
        .attr('opacity', opacity)
        .style('cursor','pointer');

      bg.append('rect')
        .attr('x', -bW/2).attr('y', -bH/2)
        .attr('width', bW).attr('height', bH)
        .attr('rx', 5)
        .attr('fill',         s.bg)
        .attr('stroke',       s.color)
        .attr('stroke-width', 0.8);

      bg.append('text')
        .attr('text-anchor',       'middle')
        .attr('dominant-baseline', 'central')
        .attr('font-family',       "'DM Sans', sans-serif")
        .attr('font-size',         '8px')
        .attr('font-weight',       '600')
        .attr('pointer-events',    'none')
        .attr('fill',              s.txt)
        .text(type);

      // Badge hover tooltip
      bg.on('mouseover', function(event) {
          _showTooltip(event, type, reason, s);
        })
        .on('mousemove', function(event) {
          _moveTooltip(event);
        })
        .on('mouseout', function() {
          _hideTooltip();
        });
    });
  }

  // ── 14.9  AUTO-FIT (85% fill, reused pattern from autoFitFullGraph) ──────────
  // Calculates exact getBBox of all rendered nodes + edges, scales to fill
  // 85% of the viewport, centres the view. Handles empty state gracefully.
  function ctAutoFit(animate) {
    var svgEl = document.getElementById('ct-svg');
    var g     = document.querySelector('#ct-svg .ct-main-g');
    if (!svgEl || !g || !ctZoom) return;

    var bounds;
    try { bounds = g.getBBox(); } catch(e) { return; }
    if (!bounds || !bounds.width || !bounds.height) return;

    var W = svgEl.clientWidth  || 800;
    var H = svgEl.clientHeight || 500;

    var PAD   = 0.85;
    var scale = Math.min((W * PAD) / bounds.width, (H * PAD) / bounds.height);
    scale = Math.min(scale, 1.2);
    scale = Math.max(scale, 0.12);

    var tx = W / 2 - scale * (bounds.x + bounds.width  / 2);
    var ty = H / 2 - scale * (bounds.y + bounds.height / 2);

    var transform = d3.zoomIdentity.translate(tx, ty).scale(scale);

    if (animate) {
      ctSVG.transition().duration(700).ease(d3.easeCubicOut)
           .call(ctZoom.transform, transform);
    } else {
      ctSVG.call(ctZoom.transform, transform);
    }
    _updateZoomPct(scale);
  }

  // ── 14.10  TOOLTIP  ──────────────────────────────────────────────────────────
  function _showTooltip(event, type, reason, s) {
    var tt = document.getElementById('ct-tooltip');
    if (!tt) return;
    tt.innerHTML =
      '<div class="ct-tt-type" style="color:' + s.txt + '">' + type + '</div>' +
      '<div class="ct-tt-reason">' + reason + '</div>';
    _moveTooltip(event);
    tt.classList.add('ct-tt-visible');
  }
  function _moveTooltip(event) {
    var tt   = document.getElementById('ct-tooltip');
    var wrap = document.getElementById('ct-canvas-wrap');
    if (!tt || !wrap) return;
    var wr = wrap.getBoundingClientRect();
    var ox = event.clientX - wr.left + 14;
    var oy = event.clientY - wr.top  + 14;
    // Flip left if near right edge
    if (ox + 270 > wrap.clientWidth)  ox = event.clientX - wr.left - 280;
    if (oy + 100 > wrap.clientHeight) oy = event.clientY - wr.top  - 110;
    tt.style.left = ox + 'px';
    tt.style.top  = oy + 'px';
  }
  function _hideTooltip() {
    var tt = document.getElementById('ct-tooltip');
    if (tt) tt.classList.remove('ct-tt-visible');
  }

  // ── 14.11  DETAIL PANEL  ─────────────────────────────────────────────────────
  function _openDetail(node) {
    var panel = document.getElementById('ct-detail');
    if (!panel) return;

    var col = CT_COLUMNS[node.col];

    // Header elements
    var badge = document.getElementById('ct-detail-badge');
    badge.style.background = col.colBg;
    badge.style.color      = col.colTxt;
    badge.textContent      = node.initials;

    document.getElementById('ct-detail-name').textContent = node.shortName;
    document.getElementById('ct-detail-year').textContent = node.year;
    document.getElementById('ct-detail-id').textContent   = node.arxiv;

    // Build body
    var outEdges    = CT_EDGES.filter(function(e){ return e[0] === node.id; });
    var inEdges     = CT_EDGES.filter(function(e){ return e[1] === node.id; });
    var contraEdges = CT_EDGES.filter(function(e){
      return (e[0] === node.id || e[1] === node.id) && e[2] === 'CONTRADICTS';
    });

    var html = '';

    // Methodology
    html += '<div class="ct-sec-title">Methodology</div>'
          + '<p class="ct-sec-body">' + _esc(node.method) + '</p>';

    // Datasets
    html += '<div class="ct-sec-title">Datasets used</div><div class="ct-sec-chips">';
    node.datasets.forEach(function(d){ html += '<span class="ct-sec-chip">' + _esc(d) + '</span>'; });
    html += '</div>';

    // Metrics
    html += '<div class="ct-sec-title">Evaluation metrics</div><div class="ct-sec-chips">';
    node.metrics.forEach(function(m){ html += '<span class="ct-sec-chip ct-sec-chip-metric">' + _esc(m) + '</span>'; });
    html += '</div>';

    // Weaknesses
    html += '<div class="ct-sec-title">Identified weaknesses</div>'
          + '<p class="ct-sec-body ct-weakness">' + _esc(node.weaknesses) + '</p>';

    // Gaps
    html += '<div class="ct-sec-title">Research gaps</div>'
          + '<p class="ct-sec-body">' + _esc(node.gaps) + '</p>';

    // Builds on / references (in-edges)
    if (inEdges.length) {
      html += '<div class="ct-sec-title">Builds on / references</div>';
      inEdges.forEach(function(e) {
        var src = CT_NODES[e[0]];
        var es  = CT_ES[e[2]] || CT_ES.RELATED;
        if (!src) return;
        html += '<div class="ct-edge-card">'
              + '<div class="ct-edge-card-head">'
              + '<span class="ct-edge-badge-pill" style="background:' + es.bg + ';color:' + es.txt + '">'
              + _esc(e[2].charAt(0) + e[2].slice(1).toLowerCase()) + '</span>'
              + '<span class="ct-edge-peer">' + _esc(src.shortName) + '</span>'
              + '<span class="ct-edge-peer-year">' + src.year + '</span>'
              + '</div>'
              + '<p class="ct-edge-reason">' + _esc(e[3]) + '</p>'
              + '</div>';
      });
    }

    // Influences / cited by (out-edges)
    if (outEdges.length) {
      html += '<div class="ct-sec-title">Influences / cited by</div>';
      outEdges.forEach(function(e) {
        var tgt = CT_NODES[e[1]];
        var es  = CT_ES[e[2]] || CT_ES.RELATED;
        if (!tgt) return;
        html += '<div class="ct-edge-card">'
              + '<div class="ct-edge-card-head">'
              + '<span class="ct-edge-badge-pill" style="background:' + es.bg + ';color:' + es.txt + '">'
              + _esc(e[2].charAt(0) + e[2].slice(1).toLowerCase()) + '</span>'
              + '<span class="ct-edge-peer">' + _esc(tgt.shortName) + '</span>'
              + '<span class="ct-edge-peer-year">' + tgt.year + '</span>'
              + '</div>'
              + '<p class="ct-edge-reason">' + _esc(e[3]) + '</p>'
              + '</div>';
      });
    }

    // Contradiction analysis
    if (contraEdges.length) {
      html += '<div class="ct-sec-title">Contradiction analysis</div>';
      contraEdges.forEach(function(e) {
        var other = (e[0] === node.id) ? CT_NODES[e[1]] : CT_NODES[e[0]];
        var role  = (e[0] === node.id) ? 'Contradicts' : 'Contradicted by';
        if (!other) return;
        html += '<div class="ct-edge-card ct-edge-card-contra">'
              + '<div class="ct-edge-card-head">'
              + '<span class="ct-edge-badge-pill" style="background:#FEF2F2;color:#991B1B">' + role + '</span>'
              + '<span class="ct-edge-peer">' + _esc(other.shortName) + '</span>'
              + '<span class="ct-edge-peer-year">' + other.year + '</span>'
              + '</div>'
              + '<p class="ct-edge-reason ct-edge-reason-contra">' + _esc(e[3]) + '</p>'
              + '</div>';
      });
    }

    // ArXiv link
    html += '<div style="margin-top:14px;">'
          + '<a href="' + node.url + '" target="_blank" rel="noopener" '
          + 'style="font-size:11px;color:#4F46E5;font-weight:600;text-decoration:none;'
          + 'display:inline-flex;align-items:center;gap:4px;">'
          + 'Open on arXiv '
          + '<svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M2 10L10 2M6 2h4v4"/></svg>'
          + '</a></div>';

    document.getElementById('ct-detail-body').innerHTML = html;
    panel.classList.add('ct-detail-open');
  }

  function ctCloseDetail() {
    ctActiveId = null;
    ctHoveredId = null;
    var panel = document.getElementById('ct-detail');
    if (panel) panel.classList.remove('ct-detail-open');
    _rebuild();

    // Also update legend bar close-button visibility
    var closeBtn = document.getElementById('ct-legend-close');
    if (closeBtn) closeBtn.style.display = 'none';
  }

  // ── 14.12  ZOOM CONTROLS  ────────────────────────────────────────────────────
  function _buildZoomControls(wrap) {
    // Remove existing if any (re-init guard)
    var old = wrap.querySelector('.ct-zoom-controls');
    if (old) old.remove();

    var div = document.createElement('div');
    div.className = 'ct-zoom-controls';

    var btnIn  = document.createElement('button');
    btnIn.className = 'ct-zoom-btn';
    btnIn.title     = 'Zoom in';
    btnIn.textContent = '+';
    btnIn.onclick = function() {
      ctSVG.transition().duration(250).call(ctZoom.scaleBy, 1.25);
    };

    var pct = document.createElement('div');
    pct.className = 'ct-zoom-pct';
    pct.id        = 'ct-zoom-pct';
    pct.textContent = '100%';

    var btnOut = document.createElement('button');
    btnOut.className  = 'ct-zoom-btn';
    btnOut.title      = 'Zoom out';
    btnOut.textContent = '\u2212';
    btnOut.onclick = function() {
      ctSVG.transition().duration(250).call(ctZoom.scaleBy, 0.8);
    };

    var sep = document.createElement('div');
    sep.style.height = '2px';

    var btnFit = document.createElement('button');
    btnFit.className = 'ct-zoom-btn';
    btnFit.title     = 'Fit to screen';
    btnFit.innerHTML = '<svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M1 4V1h3M10 1h3v3M13 10v3h-3M4 13H1v-3" stroke="#374151" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    btnFit.onclick = function() { ctAutoFit(true); };

    div.appendChild(btnIn);
    div.appendChild(pct);
    div.appendChild(btnOut);
    div.appendChild(sep);
    div.appendChild(btnFit);
    wrap.appendChild(div);
  }

  function _updateZoomPct(k) {
    var el = document.getElementById('ct-zoom-pct');
    if (el) el.textContent = Math.round(k * 100) + '%';
  }

  // ── 14.13  LEGEND BAR  ───────────────────────────────────────────────────────
  function _buildLegendBar(wrap) {
    var old = wrap.querySelector('.ct-legend-bar');
    if (old) old.remove();

    var bar = document.createElement('div');
    bar.className = 'ct-legend-bar';

    [
      { type:'EXTENDS',     label:'Extends'     },
      { type:'CONTRADICTS', label:'Contradicts' },
      { type:'OUTPERFORMS', label:'Outperforms' },
      { type:'RELATED',     label:'Related'     },
    ].forEach(function(item) {
      var s = CT_ES[item.type];
      var el = document.createElement('div');
      el.className = 'ct-legend-bar-item';
      el.innerHTML =
        '<svg width="20" height="8">'
        + '<line x1="0" y1="4" x2="20" y2="4" stroke="' + s.color + '" stroke-width="' + s.width + '"'
        + (s.dash ? ' stroke-dasharray="' + s.dash + '"' : '')
        + '/></svg>'
        + '<span>' + item.label + '</span>';
      bar.appendChild(el);
    });

    // Close-panel button (hidden when no node selected)
    var closeBtn = document.createElement('button');
    closeBtn.id        = 'ct-legend-close';
    closeBtn.className = 'ct-close-panel-btn';
    closeBtn.textContent = '\u2715 Close panel';
    closeBtn.style.display = 'none';
    closeBtn.onclick = ctCloseDetail;
    bar.appendChild(closeBtn);

    wrap.appendChild(bar);
  }

  // Show/hide close button whenever selection changes
  function _syncLegendClose() {
    var btn = document.getElementById('ct-legend-close');
    if (btn) btn.style.display = (ctActiveId !== null) ? 'inline-flex' : 'none';
  }

  // ── 14.14  PAN HANDLERS (drag on blank canvas) ────────────────────────────────
  function _onPanStart(e) {
    // Only pan on blank SVG area, not inside node rows
    if (e.target.closest && e.target.closest('.ct-node-row')) return;
    if (e.target.closest && e.target.closest('.ct-zoom-controls')) return;
    if (e.target.closest && e.target.closest('.ct-legend-bar')) return;
    ctIsPanning = true;
    ctPanStart  = { x: e.clientX, y: e.clientY };
    var wrap = document.getElementById('ct-canvas-wrap');
    if (wrap) wrap.classList.add('ct-panning');
  }
  function _onPanMove(e) {
    if (!ctIsPanning || !ctPanStart || !ctSVG || !ctZoom) return;
    var dx = e.clientX - ctPanStart.x;
    var dy = e.clientY - ctPanStart.y;
    ctPanStart = { x: e.clientX, y: e.clientY };
    var t = d3.zoomTransform(document.getElementById('ct-svg'));
    ctSVG.call(ctZoom.translateBy, dx / t.k, dy / t.k);
  }
  function _onPanEnd() {
    ctIsPanning = false;
    var wrap = document.getElementById('ct-canvas-wrap');
    if (wrap) wrap.classList.remove('ct-panning');
  }

  // ── 14.15  UTILITY  ──────────────────────────────────────────────────────────
  function _esc(str) {
    return String(str)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;');
  }

  // ── 14.16  EXPOSE initCitationTrail globally ─────────────────────────────────
  window.initCitationTrail = initCitationTrail;

}());

// ══════════════════════════════════════════════════════════════════════════════
// PAPERS PANEL — namespaced module
// Integrated from papers-section.js (standalone extraction).
//
// All logic lives inside the PapersPanel IIFE so no names pollute window scope.
// The only public surface is window.PapersPanel which exposes:
//   .build()          — render toolbar + grid into #panel-papers (idempotent)
//   .openDetail(idx)  — open detail modal for PAPERS_DATA[idx]
//   .closeModal()     — close the detail modal
//   .setYearFilter(el)— called by year-chip onclick handlers
//   .filter()         — re-render grid (called by search/sort oninput/onchange)
//
// NOTE: ext() is intentionally NOT redefined here; the parent script already
//       defines it at the top level and it is identical.
// ══════════════════════════════════════════════════════════════════════════════

window.PapersPanel = (function () {
  'use strict';

  // ── Data ─────────────────────────────────────────────────────────────────

  var PAPERS_DATA = [
    {
      id: '2602.08239', year: '2026', venue: 'arXiv', color: '#6d28d9',
      title: 'Linearized Fine-Tuning & Spectral Perturbation Bounds via NTK',
      method: 'Linearized fine-tuning with an explicit inductive bias towards the pretrained model, using the Neural Tangent Kernel (NTK) to predict fine-tuning performance at initialization.',
      datasets: ['LoRA on LLMs'],
      metrics: ['NTK eigenvalue spectrum', 'Spectral perturbation bounds', 'Condition number at-init'],
      weaknesses: ['Theoretical and empirical validation needed for all aspects of the proposed method', 'Further exploration needed for other PEFT techniques and more complex architectures'],
      unexplored: 'Further exploration of how the method applies to other PEFT techniques and more complex model architectures.',
      relations: ['EXTENDS \u2192 2110.06500', 'CONTRADICTS \u2192 2508.04848'],
    },
    {
      id: '2312.10793', year: '2023', venue: 'arXiv', color: '#BA7517',
      title: 'Mixing Instruction Datasets for LLM Fine-Tuning: A Systematic Study',
      method: 'Comprehensive experimentation across 8 combinations of instruction datasets evaluating NLP downstream tasks, coding proficiency, and chat capabilities.',
      datasets: ['P3', 'CodeAlpaca', 'Alpaca'],
      metrics: ['NLP benchmark performance', 'Code generation quality', 'Alignment evaluation'],
      weaknesses: ['Combining all instruction types does not uniformly improve performance', 'NLP-reformulated instructions can negatively impact conversational abilities', 'Larger models make more effective use of diverse instructions'],
      unexplored: 'The impact of the instruction mixture on the resulting LLM, beyond the scope of this work.',
      relations: ['EXTENDS \u2192 2510.07037', 'OUTPERFORMS \u2192 2511.21285'],
    },
    {
      id: '2402.11651', year: '2024', venue: 'arXiv', color: '#059669',
      title: 'Negative-Aware Training (NAT) for LLM Agent Fine-Tuning',
      method: 'Fine-tuning LLMs with a mix of positive and negative trajectory examples using a Negative-Aware Training (NAT) paradigm to reduce wastage of failed planning traces.',
      datasets: ['GPT-3.5/4 trajectories', 'AgentBench tasks', 'Question answering tasks'],
      metrics: ['Mathematical reasoning', 'Multi-hop question answering', 'Strategic question answering'],
      weaknesses: ['Significant wastage of data by discarding failed trajectories', 'Substantial compute wastage in tasks demanding intricate planning or tool usage'],
      unexplored: 'Effectiveness of negative samples in detail; developing better agent-tuning and low-resource data usage techniques.',
      relations: ['EXTENDS \u2192 2508.04848', 'CONTRADICTS \u2192 2402.14800', 'OUTPERFORMS \u2192 2402.14800'],
    },
    {
      id: '2110.06500', year: '2021', venue: 'arXiv', color: '#2563EB',
      title: 'Parameter-Efficient Methods for Private Fine-Tuning of Large LMs',
      method: 'Advanced parameter-efficient methods for differentially-private fine-tuning of large-scale pre-trained language models, combining DP-SGD with PEFT adapters.',
      datasets: ['RoBERTa-Large', 'RoBERTa-Base', 'MNLI', 'SST-2', 'QQP', 'QNLI'],
      metrics: ['Accuracy', 'BLEU scores'],
      weaknesses: ['DP constraint necessitates much more training data', 'Noise magnitude introduced by DP grows as model size increases'],
      unexplored: 'Parameter-efficiency in the context of private learning.',
      relations: ['EXTENDS \u2192 2602.08239', 'CONTRADICTS \u2192 2602.08239'],
    },
    {
      id: '2309.13734', year: '2023', venue: 'arXiv', color: '#E24B4A',
      title: 'Investigating LLMs for Stance Detection Across Twitter Datasets',
      method: 'Evaluating stance detection using LLMs across 6 Twitter datasets, 10 models, and 7 prompting schemes \u2014 comparing against in-domain supervised baselines.',
      datasets: ['6 Twitter datasets'],
      metrics: ['LLM vs supervised model comparison (~50% accuracy)'],
      weaknesses: ['LLMs do not routinely outperform smaller supervised models', 'Fine-tuning does not necessarily lead to better performance'],
      unexplored: 'Performance variance with data context; importance of crafting an effective input prompt.',
      relations: ['EXTENDS \u2192 2602.14406', 'CONTRADICTS \u2192 2510.20154'],
    },
    {
      id: '2508.04848', year: '2025', venue: 'arXiv', color: '#059669',
      title: 'RL Fine-Tuning of LLMs Under Non-Ideal Inference Scenarios',
      method: 'RL fine-tuning with policy gradient algorithms; evaluates LLMs under summary inference, fine-grained noise suppression, and contextual filtering conditions.',
      datasets: ['8 public datasets'],
      metrics: ['Performance degradation under non-ideal scenarios'],
      weaknesses: ['Significant performance decline in advanced reasoning under non-ideal conditions'],
      unexplored: 'Remediation strategies for non-ideal scenarios and the true reasoning abilities of RL-fine-tuned models.',
      relations: ['EXTENDS \u2192 2110.06500', 'EXTENDS \u2192 2602.08239', 'REPLICATES \u2192 2402.14800'],
    },
    {
      id: '2501.05032', year: '2025', venue: 'arXiv', color: '#0f6e56',
      title: 'DPO for Human-Like Response Generation in LLMs',
      method: 'Direct Preference Optimization (DPO) using synthetic datasets from Llama 3 405B (question gen) and Llama 3 70B (answer gen) to make LLM responses more conversational and human-like.',
      datasets: ['Synthetic via Llama 3 405B', 'Synthetic via Llama 3 70B'],
      metrics: ['Human-Likeness Evaluation'],
      weaknesses: ['Formal and impersonal default responses from LLMs', 'Ethical implications and biases of human-like AI attributes unaddressed'],
      unexplored: 'Ethical implications and potential biases introduced by human-like attributes in AI.',
      relations: ['EXTENDS \u2192 2601.11573', 'CONTRADICTS \u2192 2603.06270', 'OUTPERFORMS \u2192 2601.11573'],
    },
    {
      id: '2403.00946', year: '2024', venue: 'arXiv', color: '#BA7517',
      title: 'Fine-Tuning with High Dropout for OOD Generalization',
      method: 'Fine-tuning a large pre-trained model with very high dropout rates to encourage reliance on the most general features and improve out-of-distribution generalization.',
      datasets: ['Large weakly-related dataset', 'Task-of-interest dataset', 'OOD distribution dataset'],
      metrics: ['Out-of-distribution performance'],
      weaknesses: ['Marginally-relevant features may still be useful under different distributions', 'Intrinsically linear nature of fine-tuning on small datasets is not understood'],
      unexplored: 'Nature of rich representations and the intrinsically linear nature of fine-tuning a large network on a small dataset.',
      relations: ['EXTENDS \u2192 2110.06500', 'CONTRADICTS \u2192 2602.08239'],
    },
    {
      id: '2412.16117', year: '2024', venue: 'arXiv', color: '#2563EB',
      title: 'Training-Free Video Token Pruning for Efficient Video Understanding',
      method: 'Training-free approach for pruning video tokens to achieve efficient video understanding, combining spatiotemporal relevance scoring without any fine-tuning overhead.',
      datasets: ['Multiple video benchmarks'],
      metrics: ['Competitive performance across model networks'],
      weaknesses: ['Prior methods ignore token relevance to questions or require full prefill encoding', 'Pruning method needs improvement to better reduce inputs without performance loss'],
      unexplored: 'Improving the pruning method to better address the reduction of video inputs while maintaining high performance.',
      relations: ['EXTENDS \u2192 2602.08024', 'OUTPERFORMS \u2192 2603.10178'],
    },
    {
      id: '2310.03059', year: '2023', venue: 'arXiv', color: '#059669',
      title: 'Point-PEFT: Parameter-Efficient Fine-Tuning for 3D Point Cloud Models',
      method: 'Point-prior Prompt and a Geometry-aware Adapter framework to adapt 3D pre-trained models with minimal learnable parameters across shape classification tasks.',
      datasets: ['ModelNet40', 'ScanObjectNN'],
      metrics: ['Performance vs full fine-tuning', 'Parameter efficiency ratio'],
      weaknesses: ['Specialized PEFT for 3D pre-trained models severely under-explored', 'More downstream tasks need evaluation beyond classification'],
      unexplored: 'More specialized PEFT methods for 3D point clouds and their effectiveness across various downstream tasks.',
      relations: ['EXTENDS \u2192 2505.22444', 'OUTPERFORMS \u2192 2509.00374'],
    },
  ];

  // ── Relation badge styles (mirrors RG_COLORS in parent) ──────────────────

  var REL_STYLES = {
    EXTENDS:     { color: '#2563EB', bg: '#EFF6FF' },
    CONTRADICTS: { color: '#E24B4A', bg: '#FCEBEB' },
    OUTPERFORMS: { color: '#059669', bg: '#ECFDF5' },
    REPLICATES:  { color: '#6d28d9', bg: '#ede9fe' },
    RELATED:     { color: '#BA7517', bg: '#FAEEDA' },
  };

  // ── Module state ──────────────────────────────────────────────────────────

  var _yearFilter = 'all';

  // ── Private: HTML-escape a string safely ─────────────────────────────────

  function _esc(str) {
    return String(str)
      .replace(/&/g,  '&amp;')
      .replace(/</g,  '&lt;')
      .replace(/>/g,  '&gt;')
      .replace(/"/g,  '&quot;')
      .replace(/'/g,  '&#39;');
  }

  // ── Private: render filtered list into #pp-grid ───────────────────────────

  function _renderGrid(data) {
    var grid = document.getElementById('pp-grid');
    if (!grid) return;

    if (!data.length) {
      grid.innerHTML = '<div class="pp-empty">No papers match your filters.</div>';
      return;
    }

    grid.innerHTML = data.map(function (p, listIdx) {
      var dataIdx = PAPERS_DATA.indexOf(p);

      var relBadges = p.relations.slice(0, 2).map(function (r) {
        var type = r.split(' \u2192 ')[0];
        var s    = REL_STYLES[type] || { color: '#475569', bg: '#f1f5f9' };
        return '<span class="pp-rel-badge" style="background:' + s.bg + ';color:' + s.color + ';">' + type + '</span>';
      }).join('');

      var dsChips = p.datasets.map(function (d) {
        return '<span class="ps-ds-chip">' + _esc(d) + '</span>';
      }).join('');

      var mChips = p.metrics.map(function (m) {
        return '<span class="pp-metric-chip">' + _esc(m) + '</span>';
      }).join('');

      var wkRows = p.weaknesses.slice(0, 2).map(function (w) {
        return '<div class="pp-wk-row"><div class="pp-wk-dot"></div><span>' + _esc(w) + '</span></div>';
      }).join('');

      var shortMethod = p.method.length > 160 ? p.method.slice(0, 160) + '\u2026' : p.method;

      return [
        '<div class="pp-card" onclick="PapersPanel.openDetail(' + dataIdx + ')" style="animation-delay:' + (listIdx * 0.05) + 's">',
        '  <div class="pp-card-accent" style="background:' + p.color + ';"></div>',
        '  <div class="pp-card-body">',
        '    <div class="pp-card-top">',
        '      <div class="pp-card-id-wrap">',
        '        <span class="pp-card-id">'    + _esc(p.id)    + '</span>',
        '        <span class="pp-card-year">'  + _esc(p.year)  + '</span>',
        '        <span class="pp-card-venue">' + _esc(p.venue) + '</span>',
        '      </div>',
        '    </div>',
        '    <div class="pp-card-title">' + _esc(p.title) + '</div>',
        '    <div class="pp-card-method" style="border-left-color:' + p.color + ';">',
        '      <div class="pp-card-lbl" style="color:' + p.color + ';">Core Methodology</div>',
        _esc(shortMethod),
        '    </div>',
        '    <div class="pp-card-datasets">' + dsChips + '</div>',
        '    <div class="pp-card-metrics">'  + mChips  + '</div>',
        '    <div class="pp-card-wks">'      + wkRows  + '</div>',
        '  </div>',
        '  <div class="pp-card-footer">',
        relBadges,
        '    <span class="pp-open-btn" style="color:' + p.color + ';">View details ' + ext(10) + '</span>',
        '  </div>',
        '</div>',
      ].join('\n');
    }).join('\n');
  }

  // ── Public: build() — idempotent panel renderer ───────────────────────────

  function build() {
    var panel = document.getElementById('panel-papers');
    if (!panel) return;
    // Guard: if toolbar already injected, only re-render grid
    if (document.getElementById('pp-grid')) { _renderGrid(PAPERS_DATA); return; }

    panel.innerHTML = [
      '<div class="pp-toolbar">',
      '  <div class="pp-search">',
      '    <svg class="pp-search-icon" width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round">',
      '      <circle cx="7" cy="7" r="5"/><line x1="10.5" y1="10.5" x2="14" y2="14"/>',
      '    </svg>',
      '    <input class="pp-search-input" id="pp-search" placeholder="Search papers, methods, datasets\u2026" oninput="PapersPanel.filter()" autocomplete="off">',
      '  </div>',
      '  <div class="pp-filters" id="pp-filters">',
      '    <button class="pp-filter active" data-yr="all"  onclick="PapersPanel.setYearFilter(this)">All years</button>',
      '    <button class="pp-filter"        data-yr="2021" onclick="PapersPanel.setYearFilter(this)">2021</button>',
      '    <button class="pp-filter"        data-yr="2023" onclick="PapersPanel.setYearFilter(this)">2023</button>',
      '    <button class="pp-filter"        data-yr="2024" onclick="PapersPanel.setYearFilter(this)">2024</button>',
      '    <button class="pp-filter"        data-yr="2025" onclick="PapersPanel.setYearFilter(this)">2025</button>',
      '    <button class="pp-filter"        data-yr="2026" onclick="PapersPanel.setYearFilter(this)">2026</button>',
      '  </div>',
      '  <div class="pp-sort">',
      '    Sort:',
      '    <select id="pp-sort" onchange="PapersPanel.filter()">',
      '      <option value="year-desc">Year \u2193</option>',
      '      <option value="year-asc">Year \u2191</option>',
      '      <option value="id">arXiv ID</option>',
      '    </select>',
      '  </div>',
      '  <span class="pp-count" id="pp-count">' + PAPERS_DATA.length + ' papers</span>',
      '</div>',
      '<div class="pp-grid" id="pp-grid"></div>',
    ].join('\n');

    _renderGrid(PAPERS_DATA);
  }

  // ── Public: filter() — re-render grid from current search/year/sort state ─

  function filter() {
    var q    = ((document.getElementById('pp-search') || {}).value || '').toLowerCase();
    var sort = ((document.getElementById('pp-sort')   || {}).value || 'year-desc');

    var data = PAPERS_DATA.filter(function (p) {
      var matchYear = (_yearFilter === 'all') || (p.year === _yearFilter);
      var matchQ    = !q
        || p.title.toLowerCase().includes(q)
        || p.id.includes(q)
        || p.method.toLowerCase().includes(q)
        || p.datasets.some(function (d) { return d.toLowerCase().includes(q); });
      return matchYear && matchQ;
    });

    data = data.slice().sort(function (a, b) {
      if (sort === 'year-desc') return parseInt(b.year, 10) - parseInt(a.year, 10);
      if (sort === 'year-asc')  return parseInt(a.year, 10) - parseInt(b.year, 10);
      if (sort === 'id')        return a.id.localeCompare(b.id);
      return 0;
    });

    var countEl = document.getElementById('pp-count');
    if (countEl) countEl.textContent = data.length + ' paper' + (data.length !== 1 ? 's' : '');

    _renderGrid(data);
  }

  // ── Public: setYearFilter(btnEl) — year chip click handler ───────────────

  function setYearFilter(btnEl) {
    document.querySelectorAll('.pp-filter').forEach(function (b) { b.classList.remove('active'); });
    btnEl.classList.add('active');
    _yearFilter = btnEl.dataset.yr;
    filter();
  }

  // ── Public: openDetail(dataIdx) — populate and show paper detail modal ────

  function openDetail(dataIdx) {
    var p = PAPERS_DATA[dataIdx];
    if (!p) return;

    var accentEl = document.getElementById('pp-modal-accent');
    if (accentEl) accentEl.style.background = p.color;

    var titleEl = document.getElementById('pp-modal-title');
    if (titleEl) titleEl.textContent = p.title;

    var dsChips = p.datasets.map(function (d) {
      return '<span class="ps-ds-chip">' + _esc(d) + '</span>';
    }).join('');

    var mChips = p.metrics.map(function (m) {
      return '<span class="pp-metric-chip">' + _esc(m) + '</span>';
    }).join('');

    var wkCards = p.weaknesses.map(function (w) {
      return '<div class="pp-modal-wk">' + _esc(w) + '</div>';
    }).join('');

    var relRows = p.relations.map(function (r) {
      var parts = r.split(' \u2192 ');
      var type  = parts[0];
      var tgt   = parts[1] || '';
      var s     = REL_STYLES[type] || { color: '#475569', bg: '#f1f5f9' };
      return [
        '<div class="pp-modal-rel">',
        '  <span class="pp-modal-rel-badge" style="background:' + s.bg + ';color:' + s.color + ';">' + _esc(type) + '</span>',
        '  <span class="pp-modal-rel-text">\u2192 ' + _esc(tgt) + '</span>',
        '</div>',
      ].join('');
    }).join('');

    var bodyEl = document.getElementById('pp-modal-body');
    if (bodyEl) {
      bodyEl.innerHTML = [
        '<div class="pp-modal-section">',
        '  <div class="pp-modal-sec-title">Core Methodology</div>',
        '  <div class="pp-modal-method" style="border-left-color:' + p.color + ';">' + _esc(p.method) + '</div>',
        '</div>',
        '<div class="pp-modal-section">',
        '  <div class="pp-modal-sec-title">Datasets Used</div>',
        '  <div class="pp-modal-chips">' + dsChips + '</div>',
        '</div>',
        '<div class="pp-modal-section">',
        '  <div class="pp-modal-sec-title">Evaluation Metrics</div>',
        '  <div class="pp-modal-chips">' + mChips + '</div>',
        '</div>',
        '<div class="pp-modal-section">',
        '  <div class="pp-modal-sec-title">Identified Weaknesses</div>',
        '  <div class="pp-modal-wks">' + wkCards + '</div>',
        '</div>',
        '<div class="pp-modal-section">',
        '  <div class="pp-modal-sec-title">Unexplored Areas</div>',
        '  <div class="pp-modal-unexplored">' + _esc(p.unexplored) + '</div>',
        '</div>',
        '<div class="pp-modal-section">',
        '  <div class="pp-modal-sec-title">Paper Relations</div>',
        '  <div class="pp-modal-relations">' + relRows + '</div>',
        '</div>',
      ].join('\n');
    }

    var linkEl = document.getElementById('pp-modal-arxiv');
    if (linkEl) linkEl.href = 'https://arxiv.org/abs/' + p.id;

    var lblEl = document.getElementById('pp-modal-id-lbl');
    if (lblEl) lblEl.textContent = 'arxiv:' + p.id + ' \u00b7 ' + p.year;

    var modal = document.getElementById('pp-modal');
    if (modal) modal.classList.add('active');
  }

  // ── Public: closeModal() — dismiss the paper detail modal ─────────────────

  function closeModal() {
    var modal = document.getElementById('pp-modal');
    if (modal) modal.classList.remove('active');
  }

  // ── Keyboard: Escape closes pp-modal (only if it is open) ────────────────
  // Uses a capture check so it doesn't interfere with the parent's Escape
  // handler which closes the papers-list modal (#modal).

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      var ppModal = document.getElementById('pp-modal');
      if (ppModal && ppModal.classList.contains('active')) {
        e.stopImmediatePropagation();
        closeModal();
      }
    }
  });

  // ── Expose public API ─────────────────────────────────────────────────────

  return { build: build, filter: filter, setYearFilter: setYearFilter, openDetail: openDetail, closeModal: closeModal };

  }()); 


document.addEventListener('DOMContentLoaded', () => {
    const rawData = localStorage.getItem('oracle_data');
    const userQuery = localStorage.getItem('oracle_query');

    if (rawData) {
        try {
            const data = JSON.parse(rawData);
            hydrateDashboard(data, userQuery);
        } catch (e) {
            console.error("Failed to parse Oracle Data", e);
        }
    }

    // Initialize the dashboard AFTER data is injected so it builds with live data
    switchPanel('dashboard');
});

function hydrateDashboard(data, query) {
    // 1. Update Subtitle with user query
    const pageSub = document.getElementById('page-sub');
    if (pageSub) pageSub.innerText = `Research Intelligence overview · ${query}`;

    // Extract API Data
    const nodes = data.visual_graph_data?.nodes || [];
    const links = data.visual_graph_data?.links || [];
    const gaps = data.aggregated_gaps || [];
    const openQ = data.open_questions || [];
    const proposalText = data.generated_proposal || `Synthesis generated for ${query}`;

    // 2. INJECT INTO REACTIVE APP STATE (Auto-animates Dashboard counters)
    AppState.set({
        papers: nodes.length,
        citations: links.length,
        gaps: gaps.length,
        openQuestions: openQ.length,
        nodeCount: nodes.length,
        edgeCount: links.length
    });

    // Update Open Question badges
    document.querySelectorAll('.nav-badge, .db-qnav-badge').forEach(b => {
        b.innerText = openQ.length;
    });

    // 3. INJECT INTO D3 GRAPH_RAW
    if (nodes.length > 0) {
        GRAPH_RAW.papers = {};
        nodes.forEach(n => {
            const id = n.id || `node-${Math.random()}`;
            GRAPH_RAW.papers[id] = {
                core_methodology: n.description || n.label || 'Extracted methodology text.',
                year: n.year || new Date().getFullYear().toString(),
                pagerank: n.pagerank || Math.random() 
            };
        });

        GRAPH_RAW.graph_edges = links.map(l => {
            let rType = (l.type || l.label || 'RELATED').toUpperCase();
            if (!RG_COLORS[rType]) rType = 'RELATED'; 
            return {
                source_paper: l.source.id || l.source,
                target_paper: l.target.id || l.target,
                relationship_type: rType,
                relationship_context: l.context || 'Semantic relationship identified.'
            };
        });
    }

    // 4. HYDRATE PROPOSAL PANEL ARRAYS
    // Intercept and overwrite the static arrays used by buildProposalPanel()

    // 4a. Overwrite PROPOSAL_PAPERS
    if (nodes.length > 0) {
        PROPOSAL_PAPERS.length = 0; // Clear static array
        nodes.slice(0, 10).forEach(n => {
            PROPOSAL_PAPERS.push({
                id: n.id || 'N/A',
                year: n.year || new Date().getFullYear(),
                title: n.title || n.label || n.id,
                method: n.description || 'Methodology details extracted from agent context.',
                datasets: ['Analyzed Corpus'],
                metrics: ['Graph Connectivity'],
                weaknesses: ['Needs further empirical validation']
            });
        });
    }

    // 4b. Overwrite PROPOSAL_GAPS
    if (gaps.length > 0) {
        PROPOSAL_GAPS.length = 0; // Clear static array
        const gapThemes = [
            { color:'#E24B4A', bg:'#FCEBEB', label:'Performance' },
            { color:'#1D9E75', bg:'#E1F5EE', label:'Theory' },
            { color:'#BA7517', bg:'#FAEEDA', label:'Ethics' },
            { color:'#378ADD', bg:'#E6F1FB', label:'Efficiency' }
        ];
        
        gaps.slice(0, 8).forEach((gapText, i) => {
            const theme = gapThemes[i % gapThemes.length];
            PROPOSAL_GAPS.push({
                color: theme.color,
                bg: theme.bg,
                theme: theme.label,
                voidPct: Math.floor(Math.random() * 30) + 60, // Random void % between 60-90
                text: gapText
            });
        });
    }

    // 4c. Overwrite PROPOSAL_QUESTIONS
    if (openQ.length > 0) {
        PROPOSAL_QUESTIONS.length = 0; // Clear static array
        openQ.forEach(q => PROPOSAL_QUESTIONS.push(q));
    }

    // 5. INJECT PROPOSAL TEXT DYNAMICALLY
    // We override the original buildProposalPanel function to inject the dynamic text.
    const originalBuildProposal = window.buildProposalPanel;
    window.buildProposalPanel = function() {
        // Run original builder which uses our newly updated arrays
        originalBuildProposal();
        
        // Target the specific text blocks to update them with live API data
        const titleEl = document.querySelector('.ps-hero-title');
        const rationaleEl = document.querySelector('.ps-hero-rationale');
        
        if (titleEl) titleEl.innerHTML = `Agentic AI Synthesis:<br>Resolution path for "${query}"`;
        if (rationaleEl) rationaleEl.innerText = proposalText;
    };
}